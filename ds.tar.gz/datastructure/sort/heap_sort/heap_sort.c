#include <stdio.h>
#include <stdlib.h>
#include <string.h>


static int adjust_heap(char *arr,int index,int len)
{
	int i;
	char data=arr[index];
	for(i=index<<1;i<=len;i<<=1){
		if(i+1<=len&&arr[i]<arr[i+1])
			i++;
		if(arr[i]>data){
			arr[index]=arr[i];
			index=i;
		}
	}
	arr[index]=data;
	return 0;
}


int heap_sort(char *arr,int len)
{
	int i;
	char data;
	for(i=len/2;i>=1;i--)
		adjust_heap(arr,i,len);
	for(i=len;i>1;i--){
		data=arr[i];
		arr[i]=arr[1];
		arr[1]=data;
		adjust_heap(arr,1,i-1);
	}
	return 0;
}

int main(void)
{
	int i;
	char ch[27]={' ','l','q','w','e','r','t','a','s','d','f','g','m','h','j','k','y','u','i','o','p','z','x','c','v','b','n'};
	heap_sort(ch,26);
	for(i=1;i<=26;i++)
		printf("%c ",ch[i]);
	printf("\n");
	return 0;
}
