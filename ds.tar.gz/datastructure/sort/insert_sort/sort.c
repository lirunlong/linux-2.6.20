#include <stdio.h>
#include <stdlib.h>



static int change;

#define LEFT(r) 	(r*2+1)

static int adjust_heap(int *arr,int r,int end)
{
	int i;
	int tmp;
	tmp=arr[r];
	for(i=LEFT(r);i<=end;i=LEFT(i)){
		if(i+1<=end&&arr[i+1]>arr[i])
			i++;
		if(tmp<arr[i]){
			arr[r]=arr[i];
			r=i;
		}
		else
			break;
	}
	arr[r]=tmp;
	return 0;
}
int heap_sort(int *arr,int len)
{
	int i;
	int tmp;
	for(i=(len-2)>>1;i>=0;i--)
		adjust_heap(arr,i,len-1);	
	for(i=len-1;i>0;i--){
		tmp=arr[i];
		arr[i]=arr[0];
		arr[0]=tmp;
		adjust_heap(arr,0,i-1);
	}
	return 0;
}
int shell_sort(int *arr,int len)
{
	int inc, i,j;
	int tmp;
	for(inc=len;inc>0;inc>>=1){
		for(i=inc;i<len;i++){
			tmp=arr[i];
			for(j=i;j>=inc;j-=inc)
				if(arr[j-inc]>tmp){
					arr[j]=arr[j-inc];
					change++;
				}
				else
					break;
			arr[j]=tmp;
		}
	}
	return 0;
}

int insert_sort(int * arr,int len)
{
	int tmp;
	int i,j;
	for(i=1;i<len;i++){
		tmp=arr[i];
		for(j=i;j>0&&arr[j-1]>tmp;j--){
			arr[j]=arr[j-1];
			change++;
		}
		arr[j]=tmp;
	}
	return 0;
}

static int merge(int *arr,int *tmp,int lpos,int rpos,int rend)
{
	int lp,rp;
	int i,j;
	lp=lpos;
	rp=rpos;
	i=j=lp;
	while(lp<rpos&&rp<rend+1)
		tmp[i++]=arr[lp]>arr[rp]?arr[rp++]:arr[lp++];
	while(lp<rpos)
		tmp[i++]=arr[lp++];
	while(rp<rend+1)
		tmp[i++]=arr[rp++];
	while(j<i){
		arr[j]=tmp[j];
		j++;
	}
	return 0;
}
static int msort(int *arr,int *tmp,int left,int right)
{
	int center;
	if(left<right){
		center=(left+right)>>1;
		msort(arr,tmp,left,center);
		msort(arr,tmp,center+1,right);
		merge(arr,tmp,left,center+1,right);
	}
	return 0;
	
}
int merge_sort(int *arr,int len)
{
	int *tmparr=malloc(sizeof(int)*len);
	msort(arr,tmparr,0,len-1);
	free(tmparr);
	return 0;
}
static int partion(int *arr,int low,int high)
{
	int tmp=arr[low];
	while(low<high){
		while(low<high&&arr[high]>=tmp)
			high--;
		arr[low]=arr[high];
		while(low<high&&arr[low]<=tmp)
			low++;
		arr[high]=arr[low];
	}
	arr[low]=tmp;
	return low;
}
static int q_sort(int *arr,int low,int high)
{
	int pivotloc;
	if(low<high){
		pivotloc=partion(arr,low,high);
		q_sort(arr,low,pivotloc-1);
		q_sort(arr,pivotloc+1,high);
	}
	return 0;
}
int quick_sort(int *arr,int len)
{
	q_sort(arr,0,len-1);
	return 0;
}

int main(void)
{
	int i;
	int arr[26]={'q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j','k','l','z','x','c','v','b','n','m'};
    /*
	 *insert_sort(arr,26);
	 *shell_sort(arr,26);
	 *printf("change=%d\n",change);
	 *printf("change=%d\n",change);
	 *heap_sort(arr,26);
	 *merge_sort(arr,26);
     */
	quick_sort(arr,26);
	for(i=0;i<26;i++)
		printf("%c ",arr[i]);
	printf("\n");
	return 0;
}
