#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "d_heap.h"


#define DEGREE 			5


struct d_heap *init_heap(int max_size)
{
	struct d_heap *pheap;
	pheap=calloc(sizeof(struct d_heap),1);
	if(max_size<1){
		fprintf(stderr,"argument error\n");
		return NULL;
	}
	if(!pheap){
		fprintf(stderr,"insufficient memory\n");
		return NULL;
	}
	pheap->capacity=max_size;
	pheap->data=calloc(sizeof(char),max_size+1);
	if(!pheap->data){
		fprintf(stderr,"insufficient memory\n");
		free(pheap);
		return NULL;
	}
	return pheap;
}
static int find_min(struct d_heap * pheap,int index)
{
	int i,j,min;
	min=index;
	for(j=1,i=index+1;j<DEGREE&&i<=pheap->size;i++,j++){
		if(pheap->data[i]<pheap->data[min])
			min=i;
	}
	return min;
}
int del_min(struct d_heap *pheap,char *data)
{
	int i;
	int index;
	char ch;
	if(pheap->size<1){
		fprintf(stderr,"the heap is empty\n");
		return -1;
	}
	*data=pheap->data[1];
	ch=pheap->data[pheap->size--];
	/* adjust the heap*/
	index=1;
	for(i=index*DEGREE-DEGREE+2;i<=pheap->size;i=DEGREE*i-DEGREE+2){
		i=find_min(pheap,i);
		if(pheap->data[i]<ch){
			pheap->data[index]=pheap->data[i];
			index=i;
		}
		else
			break;
	}
	pheap->data[index]=ch;
	return 0;
}
int insert_elem(struct d_heap* pheap,char data)
{
	int i,j;
	if(pheap->size==pheap->capacity){
		fprintf(stderr,"the heap is full\n");
		return -1;
	}
	pheap->size++;
	for(j=pheap->size,i=(j+DEGREE-2)/DEGREE;i>=1&&pheap->data[i]>data;j=i,i=(i+DEGREE-2)/DEGREE)
		pheap->data[j]=pheap->data[i];
	pheap->data[j]=data;
	return 0;
}
int destroy_heap(struct d_heap *pheap)
{
	free(pheap->data);
	free(pheap);
	return 0;
}
int print_heap(struct d_heap *pheap)
{
	int i;
	for(i=1;i<=pheap->size;i++)
		printf("%c ",pheap->data[i]);
	printf("\n");
	return 0;
}
