#ifndef D_HEAP_H
#define D_HEAP_H
struct d_heap
{
	int capacity;
	int size;
	char *data;
};


struct d_heap *init_heap(int max_size);
int del_min(struct d_heap *pheap,char *data);
int insert_elem(struct d_heap* pheap,char data);
int destroy_heap(struct d_heap *pheap);
int print_heap(struct d_heap *pheap);
#endif /*D_HEAP_H*/ 
