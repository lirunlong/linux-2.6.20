#include <stdio.h>

#include "d_heap.h"


#define pr_err(fmt,args...) 		fprintf(stderr,"file %s, line %d, function %s, "fmt,__FILE__,__LINE__,__func__,##args)
#define pr_info(fmt,args...) 		printf(fmt,##args)
int main(void)
{
	char buf[256];
	char ch;
	struct d_heap * pheap;
	pheap=init_heap(50);
	if(!pheap)
		return -1;
	while(1){
		pr_info("please input a operator:\ni  insert\nd  delete\ns  show\n");
		fgets(buf,sizeof(buf),stdin);
		ch=buf[0];
		switch(ch){
			case 'i':
				printf("please input a data\n");
				fgets(buf,sizeof(buf),stdin);
				insert_elem(pheap,buf[0]);
				break;
			case 'd':
				del_min(pheap,&ch);
				break;
			case 's':
				print_heap(pheap);
				break;
			case 'q':
				goto out;
			default:
				break;
		}
	}
out:
	destroy_heap(pheap);
	return 0;
}
