#ifndef LEFT_HEAP_H
#define LEFT_HEAP_H
struct l_heap{
	char data;
	int npl;
	struct l_heap * left;
	struct l_heap * right;
};
struct l_heap*insert_elem(struct l_heap *pheap,char data);
struct l_heap * del_min(struct l_heap *pheap,char *data);
struct l_heap * merge(struct l_heap *ph1,struct l_heap *ph2);
int destroy_heap(struct l_heap *pheap);
#endif /*LEFT_HEAP_H*/ 
