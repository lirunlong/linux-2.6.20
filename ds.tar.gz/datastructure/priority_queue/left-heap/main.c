#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "left_heap.h"

#define DEFINE(type,n)  	type p##n=NULL
#define VAR(n) 				(p##n)

int pre_traverse(struct  l_heap * pheap)
{
	if(pheap){
		printf("%c:%d ",pheap->data,pheap->npl);
		pre_traverse(pheap->left);
		pre_traverse(pheap->right);
	}
	return 0;
}
int in_traverse(struct l_heap *pheap)
{
	if(pheap){
		in_traverse(pheap->left);
		printf("%c:%d ",pheap->data,pheap->npl);
		in_traverse(pheap->right);
	}
	return 0;
}

static int show_tree(struct l_heap *pheap)
{
	printf("\npre_order\n");
	pre_traverse(pheap);
	printf("\nin_order\n");
	in_traverse(pheap);
	printf("\n");
	return 0;
}


int main(void)
{
	DEFINE(struct l_heap*,1);
	DEFINE(struct l_heap*,2);
	DEFINE(struct l_heap*,3);
	DEFINE(struct l_heap*,4);
	DEFINE(struct l_heap*,5);
	DEFINE(struct l_heap*,6);
	VAR(1)=insert_elem(VAR(1),'q');
	VAR(1)=insert_elem(VAR(1),'w');
	VAR(1)=insert_elem(VAR(1),'e');
	VAR(1)=insert_elem(VAR(1),'r');

	VAR(2)=insert_elem(VAR(2),'t');
	VAR(2)=insert_elem(VAR(2),'y');
	VAR(2)=insert_elem(VAR(2),'u');
	VAR(2)=insert_elem(VAR(2),'i');

	VAR(3)=insert_elem(VAR(3),'o');
	VAR(3)=insert_elem(VAR(3),'p');
	VAR(3)=insert_elem(VAR(3),'a');
	VAR(3)=insert_elem(VAR(3),'s');

	VAR(4)=insert_elem(VAR(4),'d');
	VAR(4)=insert_elem(VAR(4),'f');
	VAR(4)=insert_elem(VAR(4),'g');
	VAR(4)=insert_elem(VAR(4),'h');

	VAR(5)=insert_elem(VAR(5),'j');
	VAR(5)=insert_elem(VAR(5),'k');
	VAR(5)=insert_elem(VAR(5),'l');
	VAR(5)=insert_elem(VAR(5),'z');

	VAR(6)=insert_elem(VAR(6),'x');
	VAR(6)=insert_elem(VAR(6),'c');
	VAR(6)=insert_elem(VAR(6),'v');
	VAR(6)=insert_elem(VAR(6),'b');
	VAR(6)=insert_elem(VAR(6),'n');
	VAR(6)=insert_elem(VAR(6),'m');

	show_tree(VAR(1));
	show_tree(VAR(2));
	show_tree(VAR(3));
	show_tree(VAR(4));
	show_tree(VAR(5));
	show_tree(VAR(6));
	VAR(1)=merge(VAR(1),VAR(2));
	VAR(2)=merge(VAR(3),VAR(4));
	VAR(3)=merge(VAR(5),VAR(6));
	show_tree(VAR(1));
	show_tree(VAR(2));
	show_tree(VAR(3));
	VAR(1)=merge(VAR(1),VAR(2));
	VAR(2)=merge(VAR(3),NULL);
	show_tree(VAR(1));
	show_tree(VAR(2));
	printf("***********************\n");
	VAR(1)=merge(VAR(1),VAR(2));
	show_tree(VAR(1));
	char c;
	while((VAR(1)=del_min(VAR(1),&c)))
		printf("%c ",c);
	printf("\n");
	getchar();
	return 0;
}
