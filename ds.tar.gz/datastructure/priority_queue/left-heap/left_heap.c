#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "left_heap.h"


struct l_heap*insert_elem(struct l_heap *pheap,char data)
{
	struct l_heap *ptmp;
	ptmp=calloc(sizeof(struct l_heap),1);
	if(!ptmp){
		fprintf(stderr,"error %d\n",__LINE__);
		return NULL;
	}
	ptmp->data=data;
	if(!pheap)
		return ptmp;
	return merge(pheap,ptmp);
}
struct l_heap * del_min(struct l_heap *pheap,char *data)
{
	struct l_heap *ptmp;
	if(!pheap){
		fprintf(stderr,"the heap is empty\n");
		return NULL;
	}
	ptmp=merge(pheap->left,pheap->right);
	*data=pheap->data;
	free(pheap);
	return ptmp;
}
#define NPL(a) 		(a?a->npl:-1)
struct l_heap * merge(struct l_heap *ph1,struct l_heap *ph2)
{
	struct l_heap *ptmp;
	if(!ph1)
		return ph2;
	if(!ph2)
		return ph1;	
	if(ph1->data<ph2->data){
		ph1->right=merge(ph1->right,ph2);
		ptmp=ph1;
	}
	else{
		ph2->right=merge(ph2->right,ph1);
		ptmp=ph2;
	}
	if(NPL(ptmp->left)<NPL(ptmp->right)){
		ph1=ptmp->left;
		ptmp->left=ptmp->right;
		ptmp->right=ph1;
	}
	ptmp->npl=NPL(ptmp->right)+1;
	return ptmp;
}
int destroy_heap(struct l_heap *pheap)
{
	if(pheap){
		destroy_heap(pheap->left);
		destroy_heap(pheap->right);
		free(pheap);
	}
	return 0;
}
