#include <stdio.h>

#include "heap.h"


int main(void)
{
	char data;
	char buf[256];
	char ch;
	struct heap * pheap;
	int ret;
	pheap=init_heap(50);
	if(!pheap)
		return -1;
	while(1){
		pr_info("please input a operator:\ni  insert\nd  delete\ns  show\n");
		fgets(buf,sizeof(buf),stdin);
		ch=buf[0];
		switch(ch){
			case 'i':
				printf("please input a data\n");
				fgets(buf,sizeof(buf),stdin);
				insert_data(pheap,buf[0]);
				break;
			case 'd':
				del_min(pheap,&ch);
				break;
			case 's':
				print_heap(pheap);
				break;
			case 'q':
				goto out;
			default:
				break;
		}
	}
out:
	destroy_heap(pheap);
	return 0;
}
