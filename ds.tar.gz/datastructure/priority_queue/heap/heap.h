#ifndef HEAP_H
#define HEAP_H


#include <stdio.h>



struct heap{
	int capacity;
	int size;
	char *data;
};
struct heap* init_heap(int maxsize);
int destroy_heap(struct heap* heap);
int find_min(struct heap * heap,char *data);
int del_min(struct heap * heap,char *pdata);
int insert_data(struct heap *heap,char data);
int print_heap(struct heap *pheap);


#define pr_err(fmt,args...) 		fprintf(stderr,"file %s, line %d, function %s, "fmt,__FILE__,__LINE__,__func__,##args)
#define pr_info(fmt,args...) 		printf(fmt,##args)

#endif /*HEAD_H*/ 
