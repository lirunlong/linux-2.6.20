
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "heap.h"


struct heap* init_heap(int maxsize)
{
	struct heap * pheap;
	if(maxsize<1){
		pr_err("error argument \n");
		return NULL;
	}
	pheap=calloc(sizeof(struct heap),1);
	if(!pheap){
		pr_err("insufficient memory\n");
		return NULL;
	}
	pheap->data=calloc(sizeof(char),maxsize+1);
	if(!pheap->data){
		pr_err("insufficient memory\n");
		free(pheap);
		return NULL;
	}
	pheap->capacity=maxsize+1;
	pheap->size=0;
	return pheap;
}
int destroy_heap(struct heap* heap)
{
	free(heap->data);
	free(heap);
	return 0;
}
int find_min(struct heap * heap,char *data)
{
	if(!heap->size){
		pr_err("the heap is empty\n");
		return -1;
	}
	*data=heap->data[1];
	return 0;
}
static int adjust_heap(struct heap *pheap,int index)
{
	char data;
	int i;
	data=pheap->data[index];
	for(i=index*2;i<=pheap->size;i*=2){
		if(i+1<=pheap->size&&pheap->data[i]>pheap->data[i+1])
			i++;
		if(pheap->data[i]<data){
			pheap->data[index]=pheap->data[i];
			index=i;
		}
		else
			break;
	}
	pheap->data[index]=data;
	return 0;
}
int del_min(struct heap * heap,char *pdata)
{
	if(!heap->size){
		pr_err("the heap is empty\n");
		return -1;
	}
	*pdata=heap->data[1];
	heap->data[1]=heap->data[heap->size];
	heap->size--;
	if(heap->size>0)
		adjust_heap(heap,1);
	return 0;
}
int insert_data(struct heap *heap,char data)
{
	int i,j;
	if(heap->size==heap->capacity){
		pr_err("the heap is full\n");
		return -1;
	}
	heap->size++;
	j=heap->size;
	i=j/2;
	while(i>=1&&heap->data[i]>data){
		heap->data[j]=heap->data[i];
		j=i;
		i>>=1;
	}
	heap->data[j]=data;
	return 0;
}
int print_heap(struct heap *pheap)
{
	int i;
	for(i=1;i<=pheap->size;i++)
		printf("%c ",pheap->data[i]);
	printf("\n");
	return 0;
}
