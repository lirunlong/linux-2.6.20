#ifndef BINOMIAL_QUEUE_H
#define BINOMIAL_QUEUE_H

struct binomial_node{
	char data;
	struct binomial_node *first_child;
	struct binomial_node *next_sibling;
};
struct binomial_queue{
	int current_size;
	int capacity;
	struct binomial_node ** trees;
}
#endif /*BINOMIAL_QUEUE_H*/ 
