#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "rbtree.h"

static struct rbtree_node * cur,*p,*gp,*ggp;
struct rbtree_node * null_node=NULL;
static struct rbtree_node * single_rotate_left(struct rbtree_node * node)
{
	struct rbtree_node * tmp;
	tmp=node->left;
	node->left=tmp->right;
	tmp->right=node;
	return tmp;
}
static struct rbtree_node * single_rotate_right(struct rbtree_node * node)
{
	struct rbtree_node * tmp;
	tmp=node->right;
	node->right=tmp->left;
	tmp->left=node;
	return tmp;
}
static struct rbtree_node * rotate(struct rbtree_node *parent,int data)
{
	if(data<parent->key)
		return parent->left=data<parent->left->key?single_rotate_left(parent->left):single_rotate_right(parent->left);
	else
		return parent->right=data>parent->right->key?single_rotate_right(parent->right):single_rotate_left(parent->right);
}
static int handlereorient(struct rbtree_node *tree)
{
	cur->color=red;
	cur->left->color=cur->right->color=black;
	if(p->color==red){
		gp->color=red;
		if((cur->key<p->key)!=(cur->key<gp->key))
			p=rotate(gp,cur->key);
		cur=rotate(ggp,p->key);
		cur->color=black;
	}
	tree->right->color=black; /*make root black*/ 
	return 0;
}
struct rbtree_node * insert(struct rbtree_node * tree,int data)
{
	cur=p=gp=ggp=tree;
	null_node->key=data;
	while(data!=cur->key){
		ggp=gp;
		gp=p;
		p=cur;
		if(data<cur->key)
			cur=cur->left;
		else
			cur=cur->right;
		if(cur->left->color==red&&cur->right->color==red)
			handlereorient(tree);
	}
	if(cur!=null_node){
		fprintf(stderr,"\33[32malready exists in tree\33[0m\n");
		return (void*)-1;
	}
	cur=calloc(sizeof(struct rbtree_node),1);
	if(!cur){
		fprintf(stderr,"insufficinet memroy\n");
		return (void*)-1;
	}
	cur->key=data;
	cur->left=cur->right=null_node;
	if(data<p->key)
		p->left=cur;
	else
		p->right=cur;
	handlereorient(tree);
	return tree;
}
struct rbtree_node * del(struct rbtree_node * tree,int data)
{
	null_node->key=data;
	cur=p=gp=ggp;
	while(data!=cur->key){
		ggp=gp;
		gp=p;
		p=cur;
		if(data<cur->key)
			cur=cur->left;
		else
			cur=cur->right;
	}
	if(cur==null_node){
		fprintf(stderr,"not found in tree\n");
		return (void*)-1;
	}
	if(cur->left==null_node){
		if(cur<p->key)
			p->left=cur->right;
		else
			p->right=cur->right;
	}
	else if(cur->right==null_node){
		if(cur<p->key)
			p->left=cur->left;
		else
			p->right=cur->left;
	}
	else{
	}
	return tree;
}
struct rbtree_node * init_tree(void)
{
	struct rbtree_node * header;
	null_node=calloc(sizeof(struct rbtree_node),1);
	if(!null_node){
		fprintf(stderr,"insufficient memroy\n");
		return NULL;
	}
	null_node->color=black;
	null_node->left=null_node->right=null_node;
	header=calloc(sizeof(struct rbtree_node),1);
	if(!header){
		fprintf(stderr,"insufficient memroy\n");
		free(null_node);
		null_node=NULL;
		return NULL;
	}
	header->color=black;
	header->right=null_node;
	header->key=(1<<(sizeof(int)*8-1));
	return header;
}
static int destroy_tree(struct rbtree_node*tree){
	if(tree!=null_node){
		destroy_tree(tree->left);
		destroy_tree(tree->right);
		free(tree);
	}
	return 0;
}
int make_empty(struct rbtree_node * tree)
{
	destroy_tree(tree->right);
	free(tree);
	free(null_node);
	null_node=NULL;
	return 0;
}
