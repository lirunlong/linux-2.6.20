#ifndef STACK_H
#define STACK_H

#include "rbtree.h"

struct stack_element
{
	struct rbtree_node *  data;
	struct stack_element * next;
};
struct stack
{
	struct stack_element * top;
	struct stack_element * base;
	int stack_size;
};


int init_stack(struct stack **pstk);
int pop(struct stack *pstk,struct rbtree_node* *pdata);
int get_top(struct stack *pstk,struct rbtree_node* *pdata);
int push(struct stack *pstk,struct rbtree_node*  data);
int destroy_stack(struct stack * pstk);
int stack_size(struct stack *pstk);
int print_stack(struct stack *pstk);

#endif   /*STACK_H*/ 
