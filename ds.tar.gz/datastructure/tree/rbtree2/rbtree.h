#pragma  once


typedef enum{red,black} color_t;

struct rbtree_node{
	int key;
	color_t color;
	struct rbtree_node *left;
	struct rbtree_node *right;
};

extern struct rbtree_node * null_node;
struct rbtree_node * insert(struct rbtree_node * tree,int data);
struct rbtree_node * del(struct rbtree_node * tree,int data);
struct rbtree_node * init_tree(void);
int make_empty(struct rbtree_node * tree);
