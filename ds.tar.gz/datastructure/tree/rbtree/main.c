#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "rbtree.h"


static int  pre_order(struct rbtree_node *tree)
{
	if(tree!=null_node){
		if(tree->color==red)
			printf("\33[31m%d\33[0m ",tree->key);
		else
			printf("%d ",tree->key);
		pre_order(tree->left);
		pre_order(tree->right);
	}
	return 0;
}
static int in_order(struct rbtree_node *tree)
{
	if(tree!=null_node){
		in_order(tree->left);
		if(tree->color==red)
			printf("\33[31m%d\33[0m ",tree->key);
		else
			printf("%d ",tree->key);
		in_order(tree->right);
	}
	return 0;
}


static int show_tree(struct rbtree_node* tree)
{
	printf("pre_order\n");
	pre_order(tree->right);
	printf("\nin_order\n");
	in_order(tree->right);
	printf("\n");
	return 0;
}

int main(void)
{
	char buf[32];
	struct rbtree_node* rbtree;
	struct rbtree_node *tmp;
	int data;
	char op;
	rbtree=init_tree();
	while(1){
		printf("please select an operator:\ni:insert an element\nd:delete an element\n"
				"s:show tree status\nq:quit\n");
		fgets(buf,sizeof(buf),stdin);
		op=buf[0];
		switch(op){
			case 'i':
				printf("please input a digit \n");
				fgets(buf,sizeof(buf),stdin);
				data=atoi(buf);	
				tmp=insert(rbtree,data);
				if(tmp!=(void*)-1)
					rbtree=tmp;
				break;
			case 'd':
				printf("please input a digit\n");
				fgets(buf,sizeof(buf),stdin);
				data=atoi(buf);
				tmp=del(rbtree,data);
				if(tmp!=(void*)-1)
					rbtree=tmp;
				break;
			case 's':
				show_tree(rbtree);
				break;
			case 'q':
				goto out;
				break;
		}
	}
out:
	make_empty(rbtree);
	return 0;
}
