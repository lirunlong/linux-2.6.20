#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rbtree.h"

struct rbtree_node * null_node=NULL;
static struct rbtree_node *cur,*p,*gp,*ggp;

static struct rbtree_node * single_rotate_left(struct rbtree_node* tree)
{
	struct rbtree_node *tmp;
	tmp=tree->left;
	tree->left=tmp->right;
	tmp->right=tree;
	return tmp;
}
static struct rbtree_node * single_rotate_right(struct rbtree_node* tree)
{
	struct rbtree_node * tmp;
	tmp=tree->right;
	tree->right=tmp->left;
	tmp->left=tree;
	return tmp;
}
static struct rbtree_node * rotate(struct rbtree_node * tree,int data)
{
	if(data<tree->key){
		return tree->left=data<tree->left->key?single_rotate_left(tree->left):\
											single_rotate_right(tree->left);
	}
	else{
		return tree->right=data<tree->right->key?single_rotate_left(tree->right):\
											single_rotate_right(tree->right);
	}
	return tree;
}
static int  handle_reorient(struct rbtree_node *tree,int data)
{
	cur->left->color=cur->right->color=black;
	cur->color=red;
	if(p->color==red){
		gp->color=red;
		if((data<p->key)!=(data<gp->key))
			p=rotate(gp,data);
		cur=rotate(ggp,data);
		cur->color=black;
	}
	tree->right->color=black;
	return 0;
}

struct rbtree_node * insert(struct rbtree_node * tree,int data)
{
	null_node->key=data;
	cur=p=gp=ggp=tree;
	while(data!=cur->key){
		ggp=gp;
		gp=p;
		p=cur;
		if(data<cur->key)
			cur=cur->left;
		else
			cur=cur->right;
		if(cur->left->color==red&&cur->right->color==red)
			handle_reorient(tree,data);
	}
	if(cur!=null_node){
		fprintf(stderr,"**************already in tree********\n");
		return (void*)-1;
	}
	cur=calloc(sizeof(struct rbtree_node),1);
	if(!cur){
		fprintf(stderr,"insufficient memory\n");
		return (void*)-1;
	}
	cur->key=data;
	cur->left=cur->right=null_node;
	if(data<p->key)
		p->left=cur;
	else
		p->right=cur;
	handle_reorient(tree,data);
	return tree;
}
struct rbtree_node * del(struct rbtree_node * tree,int data)
{
	return tree;
}
struct rbtree_node * init_tree(void)
{
	 struct rbtree_node *tree;
	 null_node=calloc(sizeof(struct rbtree_node),1);
	 if(!null_node){
		 fprintf(stderr,"insufficient memory\n");
		 return (void*)-1;
	 }
	 null_node->left=null_node->right=null_node;
	 null_node->key=~(1<<(sizeof(int)*8-1));
	 null_node->color=black;
	 tree=calloc(sizeof(struct rbtree_node),1);
	 if(!tree){
		 free(null_node);
		 null_node=NULL;
		 fprintf(stderr,"insufficient memory\n");
		 return (void*)-1;
	 }
	 tree->key=1<<(sizeof(int)*8-1);
	 tree->right=tree->left=null_node;
	 tree->color=black;
	 return tree;
}
static int destroy_tree(struct rbtree_node *tree)
{
	if(tree!=null_node){
		destroy_tree(tree->left);
		destroy_tree(tree->right);
		free(tree);
	}
	return 0;
}
int make_empty(struct rbtree_node * tree)
{
	destroy_tree(tree);
	free(null_node);
	null_node=NULL;
	return 0;
}
