#ifndef BINARY_SEARCH_TREE_H
#define BINARY_SEARCH_TREE_H
#include <stdio.h>

struct bistree
{
	int data;
	int height;
	struct bistree * left;
	struct bistree * right;
};


#define pr_dev(fmt,args...) 	fprintf(stderr,"file :%s, line :%d ,function :%s "fmt,__FILE__,__LINE__,__func__,##args)
#define pr_info(fmt,args...) 	printf(fmt,##args)
#endif /*BINARY_SEARCH_TREE_H*/ 
