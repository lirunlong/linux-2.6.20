#ifndef BISTREE_H
#define BISTREE_H
#include "../binary_search_tree.h"


struct bistree*  insert_elem(struct bistree * ptree,int data);
struct bistree*  delete_elem(struct bistree * ptree, int data);
int destroy_tree(struct bistree * ptree);
#endif /*BISTREE_H*/ 
