#include "bistree.h"


#include <string.h>
#include <stdio.h>
#include <stdlib.h>

struct bistree* insert_elem(struct bistree * ptree,int data)
{
	struct bistree * ptmp;
	if(!ptree){
		ptmp=calloc(sizeof(struct bistree),1);
		if(!ptmp){
			pr_dev("insert %d error:insufficient memroy\n",data);
			return NULL;
		}
		ptmp->data=data;
		return ptmp;
	}
	else if(data<ptree->data){
		ptmp=insert_elem(ptree->left,data);
		if(!ptmp)
			return NULL;
		ptree->left=ptmp;
		return ptree;
	}
	else if(data>ptree->data){
		ptmp=insert_elem(ptree->right,data);
		if(!ptmp)
			return NULL;
		ptree->right=ptmp;
		return ptree;
	}
	else{
		pr_dev("insert %d error: exists\n",data);
		return NULL;
	}
	
}
static struct bistree* delete_min(struct bistree * ptree,int *data)
{
	struct bistree *p1;
	struct bistree *p2;
	p1=ptree;
	p2=NULL;
	while(p1->left){
		p2=p1;
		p1=p1->left;
	}
	*data=p1->data;
	if(p2)
		p2->left=p1->right;
	else
		ptree=p1->right;
	free(p1);
	return ptree;
}
struct bistree*  delete_elem(struct bistree * ptree, int data)
{
	struct bistree * ptmp;
	if(!ptree){
		pr_dev("can not find  %d \n",data);
		return (void*)-1;
	}
	else if(data<ptree->data){
		ptmp=delete_elem(ptree->left,data);
		if(ptmp==(void*)-1)
			return ptmp;
		ptree->left=ptmp;
		return ptree;
	}
	else if(data>ptree->data){
		ptmp=delete_elem(ptree->right,data);
		if(ptmp==(void*)-1)
			return ptmp;
		ptree->right=ptmp;
		return ptree;
	}
	else if(!ptree->left){
		ptmp=ptree->right;
		free(ptree);
		return ptmp;
	}
	else if(!ptree->right){
		ptmp=ptree->left;
		free(ptree);
		return ptmp;
	}
	else{
		ptree->right=delete_min(ptree->right,&ptree->data);
		return ptree;
	}
}
int destroy_tree(struct bistree * ptree)
{
	if(ptree){
		destroy_tree(ptree->left);
		destroy_tree(ptree->right);
		free(ptree);
	}
	return 0;
}
