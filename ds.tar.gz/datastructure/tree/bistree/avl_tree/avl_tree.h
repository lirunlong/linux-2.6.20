#ifndef AVL_TREE_H
#define AVL_TREE_H


#include "../binary_search_tree.h"

struct bistree * insert_elem(struct bistree *ptree,int data);
struct bistree * delete_elem(struct bistree *ptree,int data);
int destroy_tree(struct bistree * ptree);

#endif /*AVL_TREE_H*/ 
