#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#include "avl_tree.h"

#define max(a,b) 		({typeof(a) _a=a;\
						typeof(b) _b=b;\
						(void)(&_a==&_b);\
						_a>_b?_a:_b;})

static int height(struct bistree *ptree)
{
	return ptree?ptree->height:-1;
}
/*single rotate with left*/
static struct bistree* single_rotate_left(struct bistree *pr)
{
	struct bistree * pm;
	pm=pr->left;
	pr->left=pm->right;
	pm->right=pr;
	pr->height=max(height(pr->left),height(pr->right))+1;
	pm->height=max(height(pm->left),height(pm->right))+1;
	return pm;
}
/*
 *single rotate with right
 */
static struct bistree* single_rotate_right(struct bistree *pr)
{
	struct bistree * pm;
	pm=pr->right;
	pr->right=pm->left;
	pm->left=pr;
	pr->height=max(height(pr->left),height(pr->right))+1;
	pm->height=max(height(pm->left),height(pm->right))+1;
	return pm;
}
/*
 * first single rotate with right for pr->left;
 * then single rotate with left for pr;
 */
static struct bistree* double_rotate_left(struct bistree *pr)
{
	pr->left=single_rotate_right(pr->left);
	return single_rotate_left(pr);
}
/*
 * first single  rotate with left for pr->right
 * then single rotate with right for pr;
 */
static struct bistree* double_rotate_right(struct bistree *pr)
{
	pr->right=single_rotate_left(pr->right);
	return single_rotate_right(pr);
}

struct bistree * insert_elem(struct bistree *ptree,int data)
{
	struct bistree* ptmp;
	if(!ptree){
		ptmp=calloc(sizeof(struct bistree ),1);
		if(!ptmp){
			pr_dev("insufficient memory\n");
			return NULL;
		}
		ptmp->data=data;
		return ptmp;
	}
	else if(data<ptree->data){
		ptmp=insert_elem(ptree->left,data);
		if(!ptmp)
			return NULL;
		ptree->left=ptmp;
		if(height(ptree->left)-height(ptree->right)==2){
			if(data<ptree->left->data)
				ptree=single_rotate_left(ptree);
			else
				ptree=double_rotate_left(ptree);
		}
	}
	else if(data>ptree->data){
		ptmp=insert_elem(ptree->right,data);
		if(!ptmp)
			return NULL;
		ptree->right=ptmp;
		if(height(ptree->right)-height(ptree->left)==2){
			if(data>ptree->right->data)
				ptree=single_rotate_right(ptree);
			else
				ptree=double_rotate_right(ptree);
		}
	}
	else{
		pr_dev("%d exists\n",data);
		return NULL;
	}
	ptree->height=max(height(ptree->left),height(ptree->right))+1;
	return ptree;
}

static struct bistree *delete_min(struct bistree *ptree,int *data)
{
	struct bistree * ptmp;
	if(ptree->left){
		ptmp=delete_min(ptree->left,data);
		ptree->left=ptmp;
		if(height(ptree->right)-height(ptree->left)==2){
			if(height(ptree->right->right)>height(ptree->right->left)) /*single rotate with right*/ 
				ptree=single_rotate_right(ptree);
			else
				ptree=double_rotate_right(ptree);
		}
		ptree->height=max(height(ptree->right),height(ptree->left))+1;
		return ptree;
	}
	else{
		ptmp=ptree->right;
		*data=ptree->data;
		free(ptree);
		return ptmp;
	}
}
struct bistree * delete_elem(struct bistree *ptree,int data)
{
	struct bistree * ptmp;
	if(!ptree){
		pr_dev("can not find %d \n",data);
		return (void*)-1;
	}
	else if(data<ptree->data){
		ptmp=delete_elem(ptree->left,data);
		if(ptmp==(void*)-1)
			return ptmp;
		ptree->left=ptmp;
	}
	else if(data>ptree->data){
		ptmp=delete_elem(ptree->right,data);
		if(ptmp==(void*)-1)
			return ptmp;
		ptree->right=ptmp;
	}
	else if(!ptree->left){
		ptmp=ptree->right;
		free(ptree);
		return ptmp;
	}
	else if(!ptree->right){
		ptmp=ptree->left;
		free(ptree);
		return ptmp;
	}
	else
		ptree->right=delete_min(ptree->right,&ptree->data);
	if(height(ptree->left)-height(ptree->right)==2){
		if(height(ptree->left->left)>height(ptree->left->right))
			ptree=single_rotate_left(ptree);
		else
			ptree=double_rotate_left(ptree);
	}
	else if(height(ptree->right)-height(ptree->left)==2){
		if(height(ptree->right->right)>height(ptree->right->left))
			ptree=single_rotate_right(ptree);
		else
			ptree=double_rotate_right(ptree);
	}
	ptree->height=max(height(ptree->right),height(ptree->left))+1;
	return ptree;
}
int destroy_tree(struct bistree * ptree)
{
	if(ptree){
		destroy_tree(ptree->left);
		destroy_tree(ptree->right);
		free(ptree);
	}
	return 0;
}
