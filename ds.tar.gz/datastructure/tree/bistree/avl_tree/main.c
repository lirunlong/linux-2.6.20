#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "avl_tree.h"


static int prev_traverse(struct bistree *ptree)
{
	if(ptree){
		pr_info("%d:%d  ",ptree->data,ptree->height);
		prev_traverse(ptree->left);
		prev_traverse(ptree->right);
	}
	return 0;
}
static int in_traverse(struct bistree *ptree)
{
	if(ptree){
		in_traverse(ptree->left);
		pr_info("%d ",ptree->data);
		in_traverse(ptree->right);
	}
	return 0;
}

static int show_tree(struct bistree * ptree)
{
	pr_info("prev_traverse result\n");
	prev_traverse(ptree);
	pr_info("\nin_traverse result\n");
	in_traverse(ptree);
	pr_info("\n");
	return 0;
}

int main(void)
{
	struct bistree * ptree;
	struct bistree * ptmp;
	char buf[1024];
	int data;
	ptree=NULL;
	char ch;
	while(1){
		pr_info("a insert\nb delete \nc show \nq quit\n");
		fgets(buf,sizeof(buf),stdin);
		ch=buf[0];
		switch(ch){
			case 'a':
				pr_info("please input a digit\n");
				fgets(buf,sizeof(buf),stdin);
				data=atoi(buf);
				ptmp=insert_elem(ptree,data);
				if(!ptmp)
					pr_dev("insert error\n");
				else
					ptree=ptmp;
				break;
			case 'b':
				pr_info("please input a digit to be deleted \n");
				fgets(buf,sizeof(buf),stdin);
				data=atoi(buf);
				ptmp=delete_elem(ptree,data);
				if(ptmp==(void*)-1)
					pr_dev("delete error\n");
				else
					ptree=ptmp;
				break;
			case 'c':
				show_tree(ptree);
				break;
			case 'q':
				destroy_tree(ptree);
				exit(0);
		}
	}
}
