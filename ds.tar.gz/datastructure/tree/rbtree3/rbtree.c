#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "rbtree.h"

struct rbtree_node * null_node;

static struct rbtree_node* rotate_right(struct rbtree_node * root,struct rbtree_node * node)
{
	struct rbtree_node * tmp;
	tmp=node->left;
	tmp->p=node->p;
	node->left=tmp->right;
	if(tmp->right!=null_node)
		tmp->right->p=node;
	if(node==node->p->left)
		node->p->left=tmp;
	else
		node->p->right=tmp;
	tmp->right=node;
	node->p=tmp;
	if(node==root)
		root=tmp;
	return root;
}
static struct rbtree_node * rotate_left(struct rbtree_node * root,struct rbtree_node * node)
{
	struct rbtree_node * tmp;
	tmp=node->right;
	node->right=tmp->left;
	if(tmp->left!=null_node)
		tmp->left->p=node;
	tmp->p=node->p;
	tmp->left=node;
	if(node==node->p->left)
		node->p->left=tmp;
	else
		node->p->right=tmp;
	node->p=tmp;
	if(root==node)
		root=tmp;
	return root;
}

static struct rbtree_node * insert_fixup(struct rbtree_node * root,struct rbtree_node * fix_node)
{
	fix_node->color=RED;
	struct rbtree_node * sibling;
	while(fix_node->p->color==RED){
		if(fix_node->p==fix_node->p->p->left)
			sibling=fix_node->p->p->right;
		else
			sibling=fix_node->p->p->left;
		if(sibling->color==RED){
			fix_node->p->color=sibling->color=BLACK;
			fix_node->p->p->color=RED;
			fix_node=fix_node->p->p;
		}
		else{
			if((fix_node->key<fix_node->p->key)!=(fix_node->key<fix_node->p->p->key)){
				fix_node=fix_node->p;
				root=fix_node->key<fix_node->p->key?rotate_left(root,fix_node):rotate_right(root,fix_node);
			}
			fix_node->p->color=BLACK;
			fix_node->p->p->color=RED;
			root=fix_node->key<fix_node->p->p->key ?rotate_right(root,fix_node->p->p):rotate_left(root,fix_node->p->p);
		}
	}
	root->color=BLACK;
	return root;
}
struct rbtree_node * init_tree(void)
{
	null_node=calloc(sizeof(struct rbtree_node),1);
	if(!null_node){
		fprintf(stderr,"\33[31m\33[5minsufficient memory\n\33[0m");
		return (void*)-1;
	}
	null_node->color=BLACK;
	return null_node;
}
struct rbtree_node * insert(struct rbtree_node * tree,int key)
{
	struct rbtree_node *parent;
	struct rbtree_node * cur;
	parent=null_node;
	cur=tree;
	while(cur!=null_node&&cur->key!=key){
		parent=cur;
		if(key<cur->key)
			cur=cur->left;
		else
			cur=cur->right;
	}
	if(cur!=null_node){
		fprintf(stderr,"\33[31m\33[5malready exists in the tree\n\33[0m");
		return (void*)-1;
	}
	cur=calloc(sizeof(struct rbtree_node ),1);
	if(!cur){
		fprintf(stderr,"\33[31m\33[5minsufficient memory\n\33[0m");
		return (void*)-1;
	}
	cur->key=key;
	cur->left=cur->right=null_node;
	cur->p=parent;
	if(parent==null_node)
		tree=cur;
	if(key<parent->key)
		parent->left=cur;
	else
		parent->right=cur;
	tree=insert_fixup(tree,cur);
	return tree;
}
static struct rbtree_node * del_fixup(struct rbtree_node * root,struct rbtree_node * fix_node)
{
	struct rbtree_node * siblings;
	struct rbtree_node * outchild;
	struct rbtree_node * innerchild;
	while(fix_node!=root&&fix_node->color==BLACK){
		siblings=fix_node->key<fix_node->p->key?fix_node->p->right:fix_node->p->left;
		if(siblings->color==RED){
			root=fix_node->key<fix_node->p->key?rotate_left(root,fix_node->p):rotate_right(root,fix_node->p);
			siblings->color=BLACK;
			fix_node->p->color=RED;
			siblings=fix_node->key<fix_node->p->key?fix_node->p->right:fix_node->p->left;
		}
		if(siblings->color==BLACK&&siblings->right->color==BLACK&&siblings->left->color==BLACK){
			siblings->color=RED;
			fix_node=fix_node->p;
		}
		else{/* siblings black, one or two   children are red*/
			if(siblings->key<siblings->p->key){
				outchild=siblings->left;
				innerchild=siblings->right;
			}
			else{
				outchild=siblings->right;
				innerchild=siblings->left;
			}
			if(outchild->color==BLACK){
				if(outchild->key<siblings->key){
					rotate_left(root,siblings);
					innerchild=innerchild->right;
				}
				else{
					rotate_right(root,siblings);
					outchild=siblings;
					innerchild=innerchild->left;
				}
				outchild=siblings;
				siblings=innerchild;
				siblings->color=BLACK;
				outchild->color=RED;
			}

			if(siblings->key<siblings->p->key)
				root=rotate_right(root,siblings->p);
			else
				root=rotate_left(root,siblings->p);
			siblings->color=siblings->p->color;
			outchild->color=BLACK;
			siblings->p->color=BLACK;
			fix_node=root;
		}
	}
	fix_node->color=BLACK;
	return root;
}
static struct rbtree_node * find_min(struct rbtree_node * tree)
{
	while(tree->left!=null_node)
		tree=tree->left;
	return tree;
}
struct rbtree_node * del(struct rbtree_node * tree,int key)
{
	struct rbtree_node * cur;
	struct rbtree_node * repleace_node;
	struct rbtree_node * min_node;
	cur=tree;
	null_node->key=key;
	while(key!=cur->key){
		if(key<cur->key)
			cur=cur->left;
		else
			cur=cur->right;
	}
	if(cur==null_node){
		fprintf(stderr,"\33[31m not found in tree\n\33[0m");
		return (void*)-1;
	}
	if(cur->left==null_node)
		repleace_node=cur->right;
	else if(cur->right==null_node)
		repleace_node=cur->left;
	else{
		min_node=find_min(cur->right);
		cur->key=min_node->key;
		cur=min_node;
		repleace_node=cur->right;
	}
	if(cur==tree)/* delete root node*/
		tree=repleace_node;
	else{
		if(cur==cur->p->left)
			cur->p->left=repleace_node;
		else
			cur->p->right=repleace_node;
	}
	repleace_node->p=cur->p;
	if(cur->color==BLACK)
		tree=del_fixup(tree,repleace_node);
	free(cur);
	return tree;
}
static int  destroy_tree(struct rbtree_node * tree)
{
	if(tree!=null_node){
		destroy_tree(tree->left);
		destroy_tree(tree->right);
		free(tree);
	}
	return 0;
}
int make_empty(struct rbtree_node * tree)
{
	destroy_tree(tree);
	free(null_node);
	return 0;
}
