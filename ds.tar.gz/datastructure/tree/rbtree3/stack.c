#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "stack.h"

#define pr_dev(fmt,...) fprintf(stderr,fmt,##__VA_ARGS__)
#define pr_info(fmt,...) printf(fmt,##__VA_ARGS__)

int init_stack(struct stack **pstk)
{
	struct stack *pk;
	pk=malloc(sizeof(struct stack));
	if(!pk){
		pr_dev("insufficient \n");
		return -1;
	}
	pk->base=pk->top=NULL;
	pk->stack_size=0;
	*pstk=pk;
	pr_info("init success %d\n",__LINE__);
	return 0;
}
int pop(struct stack *pstk,struct rbtree_node * *pdata)
{
	struct stack_element * pelem;
	if(pstk->stack_size>0){
		*pdata=pstk->top->data;
		pelem=pstk->top;
		pstk->top=pelem->next;
		free(pelem);
		pstk->stack_size--;
		if(!pstk->stack_size)
			pstk->base=NULL;
		return 0;
	}
	return -1;
}
int get_top(struct stack *pstk,struct rbtree_node * *pdata)
{
	if(pstk->stack_size>0){
		*pdata=pstk->top->data;
		return 0;
	}
	return -1;
}
int push(struct stack *pstk,struct rbtree_node * data)
{
	struct stack_element * pelem;
	pelem=malloc(sizeof(struct stack_element));
	if(!pelem){
		pr_dev("insuffient memory\n");
		return -1;
	}
	pelem->data=data;
	pelem->next=pstk->top;
	pstk->top=pelem;
	if(!pstk->base)
		pstk->base=pstk->top;
	pstk->stack_size++;
	return 0;
}
int destroy_stack(struct stack * pstk)
{
	int size=pstk->stack_size;
	struct stack_element *pelem;
	while(size>0){
		pelem=pstk->top;
		pstk->top=pelem->next;
		free(pelem);
		size--;
	}
	pstk->stack_size=0;
	free(pstk);
	return 0;
}
int stack_size(struct stack *pstk)
{
	return pstk->stack_size;
}

static int bnode_num;
static int p_stack(struct stack *pstk,struct stack_element *p)
{
	if(p!=pstk->base)
		p_stack(pstk,p->next);
	if(p->data->color==RED)
		printf("\33[31m%d\33[0m ",p->data->key);
	else{
		bnode_num++;
		printf("%d ",p->data->key);
	}
	return 0;
}
int print_stack(struct stack *pstk)
{
	struct stack_element *p;
	bnode_num=0;
	p=pstk->top;
	p_stack(pstk,p);
	printf(" \33[32m num of balck node is %d\n\33[0m",bnode_num);
	return 0;
}
