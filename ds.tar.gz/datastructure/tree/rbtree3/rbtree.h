#pragma once

typedef enum{RED,BLACK} color_t;

struct rbtree_node{
	int key;
	color_t color;
	struct rbtree_node *p;
	struct rbtree_node * left;
	struct rbtree_node * right;
};
extern struct rbtree_node * null_node;

struct rbtree_node * init_tree(void);
struct rbtree_node * insert(struct rbtree_node * tree,int key);
struct rbtree_node * del(struct rbtree_node * tree,int key);
int  make_empty(struct rbtree_node * tree);
