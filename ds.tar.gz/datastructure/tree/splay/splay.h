#pragma once


struct splay_node{
	int elem;
	struct splay_node * left;
	struct splay_node * right;
};



struct splay_node * splay(struct splay_node *tree,int data);
struct splay_node * insert(struct splay_node * tree,int data);
struct splay_node * del(struct splay_node * tree, int data);
int make_empty(struct splay_node*tree);
