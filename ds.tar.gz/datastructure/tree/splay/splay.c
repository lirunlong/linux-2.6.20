#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "splay.h"


static struct splay_node* single_rotate_with_left(struct splay_node *tree)
{
	struct 	splay_node * tmp;
	tmp=tree->left;
	tree->left=tmp->right;
	tmp->right=tree;
	return tmp;
}
static struct splay_node* single_rotate_with_right(struct splay_node *tree)
{
	struct splay_node *tmp;
	tmp=tree->right;
	tree->right=tmp->left;
	tmp->left=tree;
	return tmp;
}

struct splay_node * splay(struct splay_node *tree,int data)
{
	struct splay_node * left_max;
	struct splay_node * right_min;
	struct splay_node header;
	header.left=header.right=NULL;
	left_max=right_min=&header;
	while(data!=tree->elem){
		if(data<tree->elem){
			if(tree->left&&data<tree->left->elem)
				tree=single_rotate_with_left(tree);
			if(!tree->left)
				break;
			right_min->left=tree;
			right_min=tree;
			tree=tree->left;
		}
		else{
			if(tree->right&&data>tree->right->elem)
				tree=single_rotate_with_right(tree);
			if(!tree->right)
				break;
			left_max->right=tree;
			left_max=tree;
			tree=tree->right;
		}
	}
	left_max->right=tree->left;
	right_min->left=tree->right;
	tree->left=header.right;
	tree->right=header.left;
	return tree;
}
struct splay_node * insert(struct splay_node * tree,int data)
{
	struct splay_node * newnode;
	struct splay_node * position;
	newnode=calloc(sizeof(struct splay_node),1);
	if(!newnode){
		fprintf(stderr,"insufficient memory\n");
		return NULL;
	}
	newnode->elem=data;
	if(!tree)
		tree=newnode;
	else{
		position=splay(tree,data);
		if(data<position->elem){
			newnode->left=position->left;
			newnode->right=position;
			position->left=NULL;
			tree=newnode;
		}
		else if(data>position->elem){
			newnode->right=position->right;
			newnode->left=position;
			position->right=NULL;
			tree=newnode;
		}
		else{
			fprintf(stderr,"already in tree\n");
			free(newnode);
			return NULL;
		}
	}
	return tree;
}
struct splay_node * del(struct splay_node * tree, int data)
{
	struct splay_node * newtree;
	if(tree){
		tree=splay(tree,data);
		if(data==tree->elem){
			if(!tree->left)	
				newtree=tree->right;
			else{
				newtree=splay(tree->left,data);
				newtree->right=tree->right;
			}
			free(tree);
			tree=newtree;
		}
	}
	return tree;
}
int make_empty(struct splay_node*tree)
{
	if(tree){
		make_empty(tree->left);
		make_empty(tree->right);
		free(tree);
	}
	return 0;
}
static int pre_order(struct splay_node *tree)
{
	if(tree){
		printf("%d ",tree->elem);
		pre_order(tree->left);
		pre_order(tree->right);
	}
	return 0;
}
static int in_order(struct splay_node * tree)
{
	if(tree){
		in_order(tree->left);
		printf("%d ",tree->elem);
		in_order(tree->right);
	}
	return 0;
}
static int show_tree(struct splay_node *tree)
{
	printf("pre_order:\n");
	pre_order(tree);
	printf("\nin_order:\n");
	in_order(tree);
	printf("\n");
	return 0;
}
int main(void)
{
	char buf[32];
	char ch;
	int data;
	struct splay_node * tree=NULL;
	while(1){
		printf("\nplease select a op \ni:insert\nd:delete\ns:showtree\nq:quit\n");
		fgets(buf,sizeof(buf),stdin);
		ch=buf[0];
		switch(ch){
			case 'i':
				printf("input a digit\n");
				fgets(buf,sizeof(buf),stdin);
				data=atoi(buf);
				tree=insert(tree,data);/* fix me*/
				break;
			case 'd':
				printf("input a digit\n");
				fgets(buf,sizeof(buf),stdin);
				data=atoi(buf);
				tree=del(tree,data);/* fix me*/
				break;
			case 's':
				show_tree(tree);
				break;
			case 'q':
				goto out;
			default:
				break;
		}
	}
out:
	make_empty(tree);
	return 0;
}
