#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int naive_string_match(char *pstr,char *tstr)
{
	int i,j;
	i=j=0;
	while(pstr[i+j]&&tstr[j]){
		if(pstr[i+j]==tstr[j])
			j++;
		else{
			i++;
			j=0;
		}
	}
	if(!tstr[j])
		return i;
	return 0;
}
static int get_next(char *match,int *next,int len)
{
	int i,j;
	next[0]=-1;
	j=-1;
	i=0;
	while(i<len-1){
		if(j==-1||match[i]==match[j]){
			i++;j++;
			next[i]=j;
		}
		else
			j=next[j];
	}
	return 0;
}
static int kmp_match(char *pstr,char *tstr)
{
	int *next;
	char *p,*t;
	int i,j;
	i=j=0;
	p=pstr;
	t=tstr;
	int t_len=strlen(tstr);
	next=malloc(t_len*sizeof(int));
	get_next(tstr,next,t_len);
	while(j==-1||pstr[i]&&tstr[j]){
		if(j==-1||pstr[i]==tstr[j]){
			i++;
			j++;
		}
		else
			j=next[j];
	}
	free(next);
	if(!tstr[j])
		return i-j;
	return -1;
}

int main(void)
{
	char *str_p="afewewfewfewdfewfewlldsjafiefhfwekk";
	char *str_t="fewfew";
	int index=naive_string_match(str_p,str_t);
	printf("index=%d\n",index);
	index=kmp_match(str_p,str_t);
	printf("index=%d\n",index);
	return 0;
}
