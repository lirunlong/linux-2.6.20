
#include "topsort.h"
#include "stack.h"


#include <stdio.h>


static int indegree[MAX_VERTEX_NUM];
static int topnum[MAX_VERTEX_NUM];

static int topsort_index;
struct stack *pstack;


static int init_indegree(struct al_graph * pgraph)
{
	int i;
	int vtex_num;
	struct arc * parc;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++){
		parc=pgraph->vtexes[i].first_arc;
		while(parc){
			indegree[parc->index]++;
			parc=parc->next_arc;
		}
	}
	return 0;
}
static int push_zero_node(int vtex_num)
{
	int i;
	for(i=0;i<vtex_num;i++){
		if(!indegree[i])
			push(pstack,i);
	}
	return 0;
}

int topsort(struct al_graph * pgraph)
{
	int ret;
	int v,w;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	init_indegree(pgraph);
	ret=init_stack(&pstack);
	if(ret)
		return -1;
	push_zero_node(vtex_num);
	while(stack_size(pstack)>0){
		ret=pop(pstack,&v);
		if(ret)
			return -1;
		topnum[topsort_index++]=v;
		for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
			if(!--indegree[w])
				push(pstack,w);
	}
	if(topsort_index<vtex_num){
		fprintf(stderr," there is a cycle\n");
		return -1;
	}
	else{
		printf("top sort\n");
		for(v=0;v<vtex_num;v++)
			printf("%c ",pgraph->vtexes[topnum[v]].data);
		printf("\n");
	}
	destroy_stack(pstack);
	return 0;
}
