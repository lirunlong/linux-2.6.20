#ifndef TOPSORT_H
#define TOPSORT_H


#include "al_graph.h"


int topsort(struct al_graph * pgraph);


#endif /*TOPSORT_H*/ 
