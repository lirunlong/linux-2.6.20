#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tarjan.h"
#include "stack.h"


#define pr_dev(fmt,args...)  fprintf(stderr,fmt,##args)
#define pr_info(fmt,args...)  printf(fmt,##args)


#define min(a,b) 			({typeof(a) _a=a;\
								typeof(b) _b=b;\
								(void)(&_a==&_b);\
								_a<_b?_a:_b;})



static int visited[MAX_VERTEX_NUM];

static struct stack *pstak;
static int indx;

static int tarjan_depth_traverse(struct ol_graph * pgraph,int u)
{
	int w;
	int ret;
	int data;
	struct ol_vtex *pvtex;
	visited[u]=1;
	pvtex=pgraph->vtexes+u;
	pvtex->dfn=pvtex->low=indx++;
	ret=push(pstak,u);
	if(ret){
		pr_dev("file:%s  line:%d error\n",__FILE__,__LINE__);
		return -1;
	}
	for(w=first_vex(pgraph,u);w>=0;w=next_vex(pgraph,u,w))
		if(!visited[w]){
			tarjan_depth_traverse(pgraph,w);
			pvtex->low=min(pvtex->low,pgraph->vtexes[w].low);
		}
		else if(exist_in_stack(pstak,w))
			pvtex->low=min(pvtex->low,pgraph->vtexes[w].dfn);
	if(pvtex->dfn==pvtex->low){  /*find a  root of a strong connected component */ 
		pr_info("find a strong connected component\n");
		do{
			ret=pop(pstak,&data);
			if(ret){
				pr_dev("file:%s  line:%d error\n",__FILE__,__LINE__);
					return -1;
			}
			printf("%c ",pgraph->vtexes[data].data);
		}while(data!=u);
		printf("\n");
	}
	return 0;
}
int tarjan(struct ol_graph * pgraph)
{
	int i;
	int vtex_num;
	int ret;
	ret=init_stack(&pstak);
	if(ret){
		pr_dev("init stack error\n");
		return -1;
	}
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	for(i=0;i<vtex_num;i++)
		if(!visited[i])
			tarjan_depth_traverse(pgraph,i);
	destroy_stack(pstak);
	return 0;
}
