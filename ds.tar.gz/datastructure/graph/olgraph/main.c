#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ol_graph.h"
#include "tarjan.h"
#include "gabow.h"



static int get_vtex_arc_num(struct ol_graph * pgraph)
{
	int ret;     
	int vnum,anum;     
	while(1){     
		printf("please input the vertex num:\n");     
		ret=scanf("%d",&vnum);     
		getchar();     
		if(ret!=1||vnum<1||vnum>MAX_VERTEX_NUM)     
			printf("error input,please try again\n");     
		else     
			break;     
	}     
	pgraph->vtex_num=vnum;     
	while(1){     
		printf("please input the arcs num:\n");     
		ret=scanf("%d",&anum);     
		getchar();     
		if(ret!=1||anum<0||anum>(vnum*vnum))
			printf("error input ,please try again\n");     
		else     
			break;     
	}     
	pgraph->arc_num=anum; 
	return 0;
}
static int get_vtex(struct ol_graph * pgraph)
{
	int i;
	int vtex_num;
	int ret;
	char ch;
	vtex_num=pgraph->vtex_num;
	i=0;
	while(i<vtex_num){
		printf("input %d vtex:\n",i);
		ret=scanf("%c",&ch);
		getchar();
		if(ret!=1||ch>'z'||ch <'a')
			printf("error input\n");
		else{
			pgraph->vtexes[i].data=ch;
			pgraph->vtexes[i].first_in=NULL;
			pgraph->vtexes[i].first_out=NULL;
			i++;
		}
	}
	return 0;
}
static int insert_arc(struct ol_graph * pgraph,int v,int w)
{
	struct ol_arc * parc;
	parc=calloc(sizeof(struct ol_arc),1);
	if(!parc){
		fprintf(stderr, "insufficient memory\n");
		return -1;
	}
	parc->tail=v;
	parc->head=w;
	parc->tlink=pgraph->vtexes[v].first_out;
	pgraph->vtexes[v].first_out=parc;
	parc->hlink=pgraph->vtexes[w].first_in;
	pgraph->vtexes[w].first_in=parc;
	return 0;
}
static int get_arc(struct ol_graph * pgraph)
{
	int i,j,k;
	int arc_num;
	char va,ve;
	int ret;
	arc_num=pgraph->arc_num;
	i=0;
	while(i<arc_num){
		printf("input the %d arc's vtex :\n",i);
		ret=scanf("%c %c",&va,&ve);
		getchar();
		if(ret!=2)
			printf("error input,please try again!\n");
		else{
			j=locate_vex(pgraph,va);
			k=locate_vex(pgraph,ve);
			if(j>=0&&k>=0){
				ret=insert_arc(pgraph,j,k);
				if(ret){
					fprintf(stderr,"insert_arcs error\n");
					return -1;
				}
				i++;
			}
			else
				printf("error input,please try again!\n");
		}
	}
	return 0;
}
static int destroy_arc(struct ol_graph *pgraph)
{
	int i;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	struct ol_arc *parc;
	struct ol_arc *pcur;
	for(i=0;i<vtex_num;i++){
		parc=pgraph->vtexes[i].first_out;
		while(parc){
			pcur=parc->tlink;
			free(parc);
			parc=pcur;
		}
		pgraph->vtexes[i].first_out=pgraph->vtexes[i].first_in=NULL;
	}
	return 0;
}
int main(void)
{
	int ret;
	struct ol_graph graph;
	ret=get_vtex_arc_num(&graph);
	if(ret){
		fprintf(stderr,"get num error\n");
		return -1;
	}
	ret=get_vtex(&graph);
	if(ret){
		fprintf(stderr,"get vtex error\n");
		return -1;
	}
	ret=get_arc(&graph);
	if(ret){
		fprintf(stderr,"get arc error\n");
		goto arc_error;
	}
	printf("depth traverse:\n");
	ret=depth_traverse(&graph);
	if(ret){
		fprintf(stderr," depth traverse error\n");
		goto arc_error;
	}
	printf("\n");
	printf("broad traverse:\n");
	ret=broad_traverse(&graph);
	if(ret){
		fprintf(stderr," broad traverse error\n");
		goto arc_error;
	}
	printf("\n");
	printf("strong connected components\n");
	strong_connected(&graph);

	tarjan(&graph);
	printf("gabow ****************:\n");
	gabow(&graph);
	destroy_arc(&graph);
	return 0;

arc_error:
	destroy_arc(&graph);
	return -1;
}
