#ifndef GABOW_H
#define GABOW_H
#include "ol_graph.h"

int gabow(struct ol_graph* pgraph);
#endif /*GABOW_H*/ 
