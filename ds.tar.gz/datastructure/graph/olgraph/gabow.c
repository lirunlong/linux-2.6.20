
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "stack.h"
#include "ol_graph.h"

#define  pr_dev(fmt,...) fprintf(stderr,"file %s,line %d ,function:%s "fmt,__FILE__,__LINE__,__func__,##__VA_ARGS__)
#define  pr_info(fmt,...) printf(fmt,##__VA_ARGS__)

static struct stack *vpstk;
static struct stack *rpstk;
static int  indx;


static int visited[MAX_VERTEX_NUM];
static int gabow_dfs(struct ol_graph * pgraph,int u)
{
	int w;
	int ret;
	int data;
	visited[u]=1;
	pgraph->vtexes[u].dfn=indx++;
	ret=push(vpstk,u);
	if(ret){
		pr_dev("push error\n");
		return -1;
	}
	ret=push(rpstk,u);
	if(ret){
		pr_dev("push error\n");
		return -1;
	}
	for(w=first_vex(pgraph,u);w>=0;w=next_vex(pgraph,u,w))
		if(!visited[w])
			gabow_dfs(pgraph,w);
		else if(exist_in_stack(vpstk,w))
			do{
				ret=get_top(rpstk,&data);
				if(ret){
					pr_dev("get_top error\n");
					return -1;
				}
				if(pgraph->vtexes[data].dfn>pgraph->vtexes[w].dfn)
					pop(rpstk,&data);
				else
					break;
			}while(1);
	if(!get_top(rpstk,&data)&&data==u){/* find a root of a strongly connected components*/
		pop(rpstk,&data);
		pr_info("find a strongly connected components\n");
		do{
			ret=pop(vpstk,&data);
			if(ret){
				pr_dev("pop error\n");
				return -1;
			}
			printf("%c ",pgraph->vtexes[data].data);
		}while(data!=u);
		printf("\n");
	}
	return 0;
}

int gabow(struct ol_graph* pgraph)
{
	int ret;
	int i;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	ret=init_stack(&vpstk);
	if(ret){
		pr_dev("init stack error\n");
		return -1;
	}
	ret=init_stack(&rpstk);
	if(ret){
		pr_dev("init stack error\n");
		destroy_stack(vpstk);
		return -1;
	}
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	for(i=0;i<vtex_num;i++)
		if(!visited[i])
			gabow_dfs(pgraph,i);
	destroy_stack(vpstk);
	destroy_stack(rpstk);
	return 0;
}
