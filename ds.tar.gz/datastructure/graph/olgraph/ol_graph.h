#ifndef OL_GRAPH_H
#define OL_GRAPH_H

#include "../graph.h"

struct ol_arc{
	int head;
	int tail;
	struct ol_arc * hlink;
	struct ol_arc * tlink;
	void *info;
};
struct ol_vtex{
	char data;
	int dfn;
	int low;
	struct ol_arc* first_in;
	struct ol_arc * first_out;
};

struct ol_graph{
	struct ol_vtex vtexes[MAX_VERTEX_NUM];
	int vtex_num;
	int arc_num;
};

int locate_vex(struct ol_graph *pgraph,char c);
int first_vex(struct ol_graph* pgraph,int v);
int next_vex(struct ol_graph*pgraph,int v,int w);
int first_vex_reverse(struct ol_graph * pgraph,int v);
int next_vex_reverse(struct ol_graph*pgraph,int v,int w);
int depth_traverse(struct ol_graph* pgraph);
int broad_traverse(struct ol_graph* pgraph);

int strong_connected(struct ol_graph * pgraph);

#endif
