#include "ol_graph.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


static int visited[MAX_VERTEX_NUM];
static int count;
static int finished[MAX_VERTEX_NUM];


static int dfs_reverse(struct ol_graph * pgraph,int v)
{
	int w;
	visited[v]=1;
	printf("%c ",pgraph->vtexes[v].data);
	for(w=first_vex_reverse(pgraph,v);w>=0;w=next_vex_reverse(pgraph,v,w))
		if(!visited[w])
			dfs_reverse(pgraph,w);
	return 0;
}
static int depth_traverse_reverse(struct ol_graph * pgraph)
{
	int i,j;
	int vtex_num;
	j=0;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	for(i=count-1;i>=0;i--)
		if(!visited[finished[i]]){
			printf("%d strong connected:\n",j);
			dfs_reverse(pgraph,finished[i]);
			printf("\n");
			j++;
		}
	return 0;
}

static int dfs_seq(struct ol_graph * pgraph,int v)
{
	int w;
	visited[v]=1;
	for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
		if(!visited[w])
			dfs_seq(pgraph,w);
	finished[count++]=v;
	return 0;
}
static int depth_traverse_seq(struct ol_graph * pgraph)
{
	int i;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	for(i=0;i<vtex_num;i++)
		if(!visited[i])
			dfs_seq(pgraph,i);
	return 0;
}
int strong_connected(struct ol_graph * pgraph)
{
	int i;
	depth_traverse_seq(pgraph);
	printf("debug\n");
	for(i=0;i<count;i++)
		printf("%c ",pgraph->vtexes[finished[i]].data);
	printf("\n");
	depth_traverse_reverse(pgraph);
	return 0;
}
