#ifndef STACK_H
#define STACK_H

struct stack_element
{
	int data;
	struct stack_element * next;
};
struct stack
{
	struct stack_element * top;
	struct stack_element * base;
	int stack_size;
};


int init_stack(struct stack **pstk);
int pop(struct stack *pstk,int *pdata);
int get_top(struct stack *pstk,int *pdata);
int push(struct stack *pstk,int data);
int destroy_stack(struct stack * pstk);
int stack_size(struct stack *pstk);
int exist_in_stack(struct stack * pstk,int data);

#endif   /*STACK_H*/ 
