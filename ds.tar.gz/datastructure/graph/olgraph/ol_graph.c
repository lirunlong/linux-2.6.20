#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ol_graph.h"
#include "queue.h"

int locate_vex(struct ol_graph *pgraph,char c)
{
	int i;
	int vtex_num;
	struct ol_vtex *pvtx;
	pvtx=pgraph->vtexes;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		if(pvtx[i].data==c)
			return i;
	return -1;
}
int first_vex(struct ol_graph* pgraph,int v)
{
	struct ol_arc * parc;
	parc=pgraph->vtexes[v].first_out;
	if(parc)
		return parc->head;
	return -1;
}
int next_vex(struct ol_graph*pgraph,int v,int w)
{
	struct ol_arc* parc;
	parc=pgraph->vtexes[v].first_out;
	while(parc&&parc->head!=w)
		parc=parc->tlink;
	if(parc&&parc->tlink)
		return parc->tlink->head;
	return -1;
	
}
static int visit(struct ol_vtex * pvtex)
{
	printf("%c ",pvtex->data);
	return 0;
}
static int visited[MAX_VERTEX_NUM];
static int dfs_graph(struct ol_graph* pgraph,int v)
{
	int w;
	visited[v]=1;
	visit(pgraph->vtexes+v);
	for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
		if(!visited[w])
			dfs_graph(pgraph,w);
	return 0;
}
int depth_traverse(struct ol_graph* pgraph)
{
	int vtex_num;
	int i;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	for(i=0;i<vtex_num;i++)
		if(!visited[i])
			dfs_graph(pgraph,i);
	return 0;
}
int broad_traverse(struct ol_graph* pgraph)
{
	struct  queue que;
	int vtex_num;
	int ret;
	int v,w;
	int i;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	ret=init_queue(&que);
	if(ret){
		fprintf(stderr,"init queue error\n");
		return -1;
	}
	for(i=0;i<vtex_num;i++)
		if(!visited[i]){
			visited[i]=1;
			visit(pgraph->vtexes+i);
			ret=enqueue(&que,i);
			if(ret){
				fprintf(stderr,"enqueue error\n");
				return -1;
			}
			while(queue_num(&que)>0){
				ret=dequeue(&que,&v);
				if(ret){
					fprintf(stderr,"dequeue error\n");
					return -1;
				}
				for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
					if(!visited[w]){
						visited[w]=1;
						visit(pgraph->vtexes+w);
						ret=enqueue(&que,w);
						if(ret){
							fprintf(stderr,"enqueue error\n");
							return -1;
						}
					}
			}
		}
	destroy_queue(&que);
	return 0;
}
int first_vex_reverse(struct ol_graph * pgraph,int v)
{
	struct  ol_arc *parc;
	parc=pgraph->vtexes[v].first_in;
	if(parc)
		return parc->tail;
	return -1;
}
int next_vex_reverse(struct ol_graph*pgraph,int v,int w)
{
	struct ol_arc * parc;
	parc=pgraph->vtexes[v].first_in;
	while(parc&&parc->tail!=w)
		parc=parc->hlink;
	if(parc&&parc->hlink)
		return parc->hlink->tail;
	return -1;
}
