#ifndef TARJAN_H
#define TARJAN_H
#include "ol_graph.h"


int tarjan(struct ol_graph *pgraph);
#endif
