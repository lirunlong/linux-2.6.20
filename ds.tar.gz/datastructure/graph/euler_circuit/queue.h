#ifndef QUEUE_H
#define QUEUE_H


struct queue_node{
	int data;
	struct queue_node *next;
};

struct queue{
	struct queue_node *front;
	struct queue_node *rear;
	int queue_num;
};


int init_queue(struct queue * pqueue);
int destroy_queue(struct queue* pqueue);
int enqueue(struct queue*pqueue,int data);
int dequeue(struct queue*pqueue,int *pdata);
int queue_num(struct queue*pqueue);
#endif /*QUEUE_H */
