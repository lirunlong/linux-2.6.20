#include <stdio.h>
#include <stdlib.h>

#include "queue.h"


int init_queue(struct queue * pqueue)
{
	pqueue->front=pqueue->rear=malloc(sizeof(struct queue_node));
	if(!pqueue->front){
		fprintf(stderr,"malloc(3) error\n");
		return -1;
	}
	pqueue->front->next=NULL;
	pqueue->queue_num=0;
	return 0;
}
int destroy_queue(struct queue* pqueue)
{
	struct queue_node *p;
	while(pqueue->front->next){
		p=pqueue->front->next;
		pqueue->front->next=p->next;
		free(p);
	}
	free(pqueue->front);
	return 0;
}
int enqueue(struct queue*pqueue,int data)
{
	struct queue_node *p;
	p=malloc(sizeof(struct queue_node));
	if(!p){
		fprintf(stderr,"malloc(30 error\n");
		return -1;
	}
	p->data=data;
	p->next=NULL;
	pqueue->rear->next=p;
	pqueue->rear=p;
	pqueue->queue_num++;
	return 0;
}
int dequeue(struct queue*pqueue,int *pdata)
{
	struct queue_node *p;
	if(pqueue->front->next){
		p=pqueue->front->next;
		pqueue->front->next=p->next;
		*pdata=p->data;
		if(pqueue->rear==p)
			pqueue->rear=pqueue->front;
		free(p);
		pqueue->queue_num--;
		return 0;
	}
	return -1;
}
int queue_num(struct queue*pqueue)
{
	return pqueue->queue_num;
}
