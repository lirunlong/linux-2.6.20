#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "biconnected.h"

static int visited[MAX_VERTEX_NUM];
static int low[MAX_VERTEX_NUM];
static int indx;
static int count;


static int find_art(struct al_graph *pgraph,int v)
{
	int w;
	count++;
	visited[v]=low[v]=++indx;
	for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
		if(!visited[w]){
			find_art(pgraph,w);
			if(low[w]<low[v])
				low[v]=low[w];
			if(low[w]>=visited[v])
				printf("articulation point %c \n",pgraph->vtexes[v].data);
		}
		else{
			if(visited[w]<low[v])
				low[v]=visited[w];
		}
	return 0;
}

int biconnected(struct al_graph * pgraph)
{
	int i,vnum,first,w;
	indx=0;
	count=0;
	vnum=pgraph->vtex_num;
	for(i=0;i<vnum;i++)
		visited[i]=0;
	
	i=0;
	first=0;
	visited[i]=low[i]=++indx;
	count++;
	for(w=first_vex(pgraph,i);w>=0;w=next_vex(pgraph,i,w)){
		if(!visited[w]){
			find_art(pgraph,w);
			if(!first){
				first=1;
				if(count<vnum)
					printf("articulatio point:%c \n",pgraph->vtexes[i].data);
			}
		}
	}

	if(count<vnum)
		printf("a not connected graph\n");
	for(i=0;i<vnum;i++){
		printf("%c:visit=%d,low=%d\n",pgraph->vtexes[i].data,visited[i],low[i]);
	}
	return 0;
}
