#pragma once

#include "al_graph.h"
int biconnected(struct al_graph * pgraph);
