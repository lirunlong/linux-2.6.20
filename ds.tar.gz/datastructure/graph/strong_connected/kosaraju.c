#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#include "kosaraju.h"

static int visited[MAX_VERTEX_NUM];
static int finished[MAX_VERTEX_NUM];
static int count;


static int dfs_seq(struct al_graph * pgraph,int v)
{
	int w;
	visited[v]=1;
	for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
		if(!visited[w])
			dfs_seq(pgraph,w);
	finished[count++]=v;
	return 0;
}

static int depth(struct al_graph *pgraph)
{
	int i;
	count=0;
	int vnum=pgraph->vtex_num;
	for (i = 0; i < vnum; i++) 
		visited[i]=0;
	for (i = 0; i < vnum; i++) 
		if(!visited[i])
			dfs_seq(pgraph,i);
	return 0;
}
static int dfs_reverse(struct al_graph * pgraph,int v)
{
	int w;
	visited[v]=1;
	for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
		if(!visited[w])
			dfs_reverse(pgraph,w);
	printf("%c ",pgraph->vtexes[v].data);
	return 0;
}
static int depth_reverse(struct al_graph * pgraph)
{
	int i;
	int vnum;
	vnum=pgraph->vtex_num;
	for(i=0;i<vnum;i++)
		visited[i]=0;
	for(i=finished[--count];count>=0;i=finished[--count])
		if(!visited[i]){
			printf("find a strongly connected components:");
			dfs_reverse(pgraph,i);
			printf("\n");
		}
	return 0;
}
static struct al_graph * reverse(struct al_graph *pgraph)
{
	int i;
	int vnum;
	struct arc * parc,*tmp;
	vnum=pgraph->vtex_num;
	struct al_graph *rev;
	rev=calloc(sizeof(struct al_graph),1);
	if(!rev)
		return NULL;
	rev->vtex_num=vnum;
	rev->arc_num=pgraph->arc_num;
	rev->kind=pgraph->kind;
	for(i=0;i<vnum;i++){
		rev->vtexes[i].data=pgraph->vtexes[i].data;
		parc=pgraph->vtexes[i].first_arc;
		while(parc){
			tmp=rev->vtexes[parc->index].first_arc;
			rev->vtexes[parc->index].first_arc=calloc(sizeof(struct arc),1);
			if(!rev->vtexes[parc->index].first_arc){
				rev->vtexes[parc->index].first_arc=tmp;
				return NULL;
			}
			rev->vtexes[parc->index].first_arc->index=i;
			rev->vtexes[parc->index].first_arc->next_arc=tmp;
			parc=parc->next_arc;
		}
	}
	return rev;
}
static int destroy_graph(struct al_graph* pgraph)
{
	int i;
	int vnum;
	struct arc *parc;
	struct arc **ppbase;
	vnum=pgraph->vtex_num;
	for(i=0;i<vnum;i++){
		ppbase=&pgraph->vtexes[i].first_arc;
		parc=*ppbase;
		while(parc){
			*ppbase=parc->next_arc;
			free(parc);
			parc=*ppbase;
		}
	}
	free(pgraph);
	return 0;
}
int kosaraju(struct al_graph *pgraph)
{
	struct al_graph *rev;
	depth(pgraph);
	rev=reverse(pgraph);
	if(!rev)
		return -1;
	depth_reverse(rev);
	destroy_graph(rev);
	return 0;
}
