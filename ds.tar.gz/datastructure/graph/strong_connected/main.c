#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "al_graph.h"
#include "connected.h"



static int get_vnum_arcnum(struct al_graph * pgraph)
{
	int ret;
	int vnum,anum;
	while(1){
		printf("please input the vertex num:\n");
		ret=scanf("%d",&vnum);
		getchar();
		if(ret!=1||vnum<1||vnum>MAX_VERTEX_NUM)
			printf("error input,please try again\n");
		else
			break;
	}
	pgraph->vtex_num=vnum;
	while(1){
		printf("please input the arcs num:\n");
		ret=scanf("%d",&anum);
		getchar();
		if(ret!=1||anum<0||anum>(vnum*(vnum-1))/2)
			printf("error input ,please try again\n");
		else
			break;
	}
	pgraph->arc_num=anum;
	return 0;
}

static int get_vtex(struct al_graph * pgraph)
{
	int i;
	int vtex_num;
	int ret;
	char ch;
	vtex_num=pgraph->vtex_num;
	i=0;
	while(i<vtex_num){
		printf("input %d vtex:\n",i);
		ret=scanf("%c",&ch);
		getchar();
		if(ret!=1||ch>'z'||ch <'a')
			printf("error input\n");
		else{
			pgraph->vtexes[i].data=ch;
			i++;
		}
	}
	return 0;
}

static int insert_arcs(struct al_graph* pgraph,int v,int w)
{
	struct vtex_node* pvtex;
	struct arc *arcv;
	pvtex=pgraph->vtexes;
	arcv=calloc(sizeof(struct arc),1);
	if(!arcv)
		goto arcv_err;
	arcv->index=w;
	arcv->next_arc=pvtex[v].first_arc;
	pvtex[v].first_arc=arcv;

	return 0;

	free(arcv);
arcv_err:
	fprintf(stderr,"insufficient memory\n");
	return -1;
}
static int get_arcs(struct al_graph*pgraph)
{
	int i,j,k;
	int arc_num;
	char va,ve;
	int ret;
	arc_num=pgraph->arc_num;
	i=0;
	while(i<arc_num){
		printf("input the %d arc's vtex :\n",i);
		ret=scanf("%c %c",&va,&ve);
		getchar();
		if(ret!=2)
			printf("error input,please try again!\n");
		else{
			j=locate_vex(pgraph,va);
			k=locate_vex(pgraph,ve);
			if(j>=0&&k>=0){
				ret=insert_arcs(pgraph,j,k);
				if(ret){
					fprintf(stderr,"insert_arcs error\n");
					return -1;
				}
				i++;
			}   
			else
				printf("error input,please try again!\n");
		}
	}   
	return 0;
}
static int destroy_arcs(struct al_graph* pgraph)
{
	int i;
	int vtex_num;
	struct arc *parc;
	struct arc **ppbase;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++){
		ppbase=&pgraph->vtexes[i].first_arc;
		parc=*ppbase;
		while(parc){
			*ppbase=parc->next_arc;
			free(parc);
			parc=*ppbase;
		}
	}
	return 0;
}
int main(void)
{
	int ret;
	int i;
	int vnum;
	struct al_graph graph;
	ret=get_vnum_arcnum(&graph);
	if(ret){
		fprintf(stderr,"get num error\n");
		goto get_num_err;
	}

	vnum=graph.vtex_num;
	for(i=0;i<vnum;i++)
		graph.vtexes[i].first_arc=NULL;
	ret=get_vtex(&graph);
	if(ret){
		fprintf(stderr,"get vtex error\n");
		goto  get_vtex_err;
	}
	ret=get_arcs(&graph);
	if(ret){
		fprintf(stderr,"get arcs error\n");
		goto get_arcs_err;
	}

    /*
	 *printf("depth traverse:\n");
	 *ret=depth_traverse(&graph);
	 *printf("\n");
	 *if(ret){
	 *    fprintf(stderr,"depth traverse error\n");
	 *    return -1;
	 *}
	 *printf("broad traverse:\n");
	 *ret=broad_traverse(&graph);
	 *printf("\n");
	 *if(ret){
	 *    fprintf(stderr,"broad traverse error\n");
	 *    return -1;
	 *}
     */
	printf("kosaraju algorithm:\n");
	conn_kosaraju(&graph);
	printf("tarjan algorithm:\n");
	conn_tarjan(&graph);
	printf("gabow algorithm:\n");
	conn_gabow(&graph);
	destroy_arcs(&graph);
	return 0;

get_arcs_err:
	destroy_arcs(&graph);
get_vtex_err:
get_num_err:
	return -1;
}
