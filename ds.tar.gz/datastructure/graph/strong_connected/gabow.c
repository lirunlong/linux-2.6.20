#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "stack.h"
#include "gabow.h"

static  struct stack *psk_a;
static  struct stack *psk_b;
static int visited[MAX_VERTEX_NUM];
static int dfn[MAX_VERTEX_NUM];
static int indx;
static int gabow_dfs(struct al_graph * pgraph,int v)
{
	int w;
	int data;
	int ret;
	visited[v]=1;
	dfn[v]=indx++;
	push(psk_a,v);
	push(psk_b,v);
	for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
		if(!visited[w])
			gabow_dfs(pgraph,w);
		else if(exist_in_stack(psk_a,w)){
			do{
			ret=get_top(psk_b,&data);
			if(ret)
				return -1;
			if(dfn[data]>dfn[w]){
				if(pop(psk_b,&data))
					return -1;
			}
			else
				break;
			}while(1);
		}
	if(!get_top(psk_b,&data)&&data==v){/* find */
		pop(psk_b,&data);
		printf("find a strongly connected components:");
		do{
			ret=pop(psk_a,&data);
			if(ret)
				return -1;
			printf("%c ",pgraph->vtexes[data].data);
		}while(data!=v);
		printf("\n");
	}
	return 0;
}
int gabow(struct al_graph * pgraph)
{
	int ret,i,vnum;
	indx=0;
	ret=init_stack(&psk_a);
	if(ret)
		return -1;
	ret=init_stack(&psk_b);
	if(ret){
		destroy_stack(psk_a);
		return -1;
	}
	vnum=pgraph->vtex_num;
	for(i=0;i<vnum;i++)
		visited[i]=0;
	for(i=0;i<vnum;i++)
		if(!visited[i])
			gabow_dfs(pgraph,i);

	destroy_stack(psk_a);
	destroy_stack(psk_b);
	return 0;
}
