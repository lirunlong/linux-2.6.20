#pragma once
#include "al_graph.h"

int gabow(struct al_graph * pgraph);
