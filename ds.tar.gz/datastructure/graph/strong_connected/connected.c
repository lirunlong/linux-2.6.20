#include "connected.h"
#include "tarjan.h"
#include "kosaraju.h"
#include "gabow.h"


connected conn_kosaraju=kosaraju;
connected conn_tarjan=tarjan;
connected conn_gabow=gabow;
