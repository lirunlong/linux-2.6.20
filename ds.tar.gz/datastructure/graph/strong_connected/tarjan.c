#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "tarjan.h"
#include "stack.h"

static struct stack  *pstak; 
static int dfn[MAX_VERTEX_NUM];
static int low[MAX_VERTEX_NUM];
static int visited[MAX_VERTEX_NUM];
static int indx;


static int dfs(struct al_graph * pgraph,int v)
{
	int w;
	int data;
	int ret;
	visited[v]=1;
	dfn[v]=low[v]=indx++;
	push(pstak,v);
	for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
		if(!visited[w]){
			dfs(pgraph,w);
			if(low[v]>low[w])
				low[v]=low[w];
		}
		else{
			if(exist_in_stack(pstak,w)&&low[v]>dfn[w])
				low[v]=dfn[w];
		}
	if(low[v]==dfn[v]){/*find a strongly connected components*/
		printf("find a strongly connected components:");
		do{
			ret=pop(pstak,&data);
			if(ret)
				return -1;
			printf("%c ",pgraph->vtexes[data].data);

		}while(data!=v);
		printf("\n");
	}
	return 0;
}
int tarjan(struct al_graph * pgraph)
{
	int ret;
	int i;
	int vnum;
	ret=init_stack(&pstak);
	if(ret)
		return -1;
	indx=0;
	vnum=pgraph->vtex_num;
	for(i=0;i<vnum;i++)
		visited[i]=0;
	for(i=0;i<vnum;i++)
		if(!visited[i])
			dfs(pgraph,i);
	free(pstak);
	return 0;
}
