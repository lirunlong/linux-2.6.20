#pragma once
#include "al_graph.h"
int tarjan(struct al_graph * pgraph);
