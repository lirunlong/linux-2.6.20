#pragma once
#include "al_graph.h"


int kosaraju(struct al_graph *pgraph);
