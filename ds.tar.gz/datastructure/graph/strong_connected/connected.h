#pragma once

#include "al_graph.h"

typedef int (*connected)(struct al_graph*pgraph);
extern connected conn_kosaraju;
extern connected conn_tarjan;
extern connected conn_gabow;
