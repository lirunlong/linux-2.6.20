#pragma once

#include "al_graph.h"

struct table_rec{
	int v;
	int known;
	int weight;
	int path;
};


int prim (struct al_graph * pgraph);
