#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#include "prim.h"

static struct table_rec recs[MAX_VERTEX_NUM];



static int find_min(struct al_graph * pgraph)
{
	int vnum,i,min;
	vnum=pgraph->vtex_num;
	min=-1;
	for(i=0;i<vnum;i++)
		if(!recs[i].known)
			if((min==-1&&recs[i].weight!=-1)||(min!=-1&&(unsigned)recs[i].weight<(unsigned)recs[min].weight))
				min=i;
	return min;
}

static int init_table(struct al_graph * pgraph,int v)
{
	int vnum,i;
	vnum=pgraph->vtex_num;
	for(i=0;i<vnum;i++){
		recs[i].v=i;
		recs[i].known=0;
		recs[i].weight=-1;
		recs[i].path=-1;
	}
	recs[v].weight=0;
	return 0;
}

static int print_result(struct al_graph * pgraph)
{
	int vnum,i;
	int weight;
	weight=0;
	vnum=pgraph->vtex_num;
	for(i=0;i<vnum;i++)
		if(recs[i].path!=-1){
			weight+=recs[i].weight;
			printf("(%c,%c) ",pgraph->vtexes[recs[i].path].data,pgraph->vtexes[i].data);
		}
	printf("\nweight=%d\n",weight);
	return 0;
}
int prim(struct al_graph * pgraph)
{
	int v,w;
	int weight;
	init_table(pgraph,0);
	while(1){
		v=find_min(pgraph);
		if(v==-1)
			break;
		recs[v].known=1;
		for(w=first_vex(pgraph,v,&weight);w>=0;w=next_vex(pgraph,v,w,&weight))
			if(!recs[w].known)
				if(recs[w].weight==-1||recs[w].weight>weight){
					recs[w].weight=weight;
					recs[w].path=v;
				}
	}
	print_result(pgraph);
	return 0;
}
