#pragma once

#include "aml_graph.h"


struct heap{
	int capacity;
	int cur_size;
	struct aml_edge **pedge;
};



struct heap * init_heap(int max_size);
int destroy_heap(struct heap* pheap);
int delete_min(struct heap* pheap,struct aml_edge**pedge); 
int insert_elem(struct heap* pheap,struct aml_edge*pedge);
