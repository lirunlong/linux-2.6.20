#pragma once
#include "aml_graph.h"


int kruskal(struct aml_graph *pgraph);
