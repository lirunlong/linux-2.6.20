
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "heap.h"

struct heap * init_heap(int max_size)
{
	struct heap * pheap;
	pheap=calloc(sizeof(struct heap),1);
	if(!pheap)
		return NULL;
	pheap->pedge=calloc(sizeof(struct aml_edge*),max_size+1);
	if(!pheap->pedge){
		free(pheap);
		return NULL;
	}
	pheap->capacity=max_size;
	pheap->cur_size=0;
	return pheap;
}
int destroy_heap(struct heap* pheap)
{
	free(pheap->pedge);
	free(pheap);
	return 0;
}
int delete_min(struct heap* pheap,struct aml_edge**pedge)
{
	int index,j;
	struct aml_edge *tmp;
	if(pheap->cur_size<1)
		return -1;
	*pedge=pheap->pedge[1];
	tmp=pheap->pedge[pheap->cur_size--];
	index=1;
	for(j=index<<1;j<=pheap->cur_size;j<<=1){
		if(j+1<=pheap->cur_size&&pheap->pedge[j]->weight>pheap->pedge[j+1]->weight)
			j++;
		if(tmp->weight>pheap->pedge[j]->weight){
			pheap->pedge[index]=pheap->pedge[j];
			index=j;
		}
		else
			break;
	}
	pheap->pedge[index]=tmp;
	return 0;
}
int insert_elem(struct heap* pheap,struct aml_edge*pedge)
{
	int index,j;
	if(pheap->cur_size==pheap->capacity)
		return -1;
	index=++pheap->cur_size;
	j=index>>1;
	while(j>=1&&pheap->pedge[j]->weight>pedge->weight){
		pheap->pedge[index]=pheap->pedge[j];
		index=j;
		j>>=1;
	}
	pheap->pedge[index]=pedge;
	return 0;
}
