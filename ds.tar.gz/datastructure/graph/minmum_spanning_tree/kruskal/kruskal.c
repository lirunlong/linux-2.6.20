#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "kruskal.h"
#include "disjset.h"
#include "heap.h"

static struct heap * pheap;
static struct disjset * pset;

static int read_to_heap(struct aml_graph*pgraph)
{
	int i;
	int edge_num;
	edge_num=pgraph->edge_num;
	for(i=0;i<edge_num;i++)
		insert_elem(pheap,pgraph->pedge[i]);
	return 0;
}

int kruskal(struct aml_graph *pgraph)
{
	struct aml_edge *pedge;
	int j=0;
	int root1,root2;
	int weight;
	int ret;
	int vnum;
	weight=0;
	vnum=pgraph->vtex_num;
	pheap=init_heap(256);
	read_to_heap(pgraph);
	pset=init_set(MAX_VERTEX_NUM);
	while(j<vnum-1){
		ret=delete_min(pheap,&pedge);
		if(ret==-1)
			return -1;
		if((root1=find(pset,pedge->ivex))==(root2=find(pset,pedge->jvex)))
			continue;
		union_set(pset,root1,root2);
		printf("(%c,%c)  ",pgraph->vtexes[pedge->ivex].data,pgraph->vtexes[pedge->jvex].data);
		weight+=pedge->weight;
		j++;
	}
	printf("\n weight=%d\n",weight);
	destroy_set(pset);
	destroy_heap(pheap);
	return 0;
}
