#pragma once


struct disjset{
	int size;
	int capacity;
	int *data;
};

struct disjset* init_set(int max_size);
int destroy_set(struct disjset * set);
int find(struct disjset *set,int data);
int  union_set(struct  disjset * set,int root1,int root2);
