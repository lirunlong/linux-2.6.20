#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#include "disjset.h"


struct disjset* init_set(int max_size)
{
	struct disjset * pset;
	int i;
	pset=calloc(sizeof(struct disjset),1);
	if(!pset)
		return NULL;
	pset->data=malloc(sizeof(int)*max_size);
	if(!pset->data){
		free(pset);
		return NULL;
	}
	for(i=0;i<max_size;i++)
		pset->data[i]=-1;
	pset->capacity=max_size;
	pset->size=0;
	return pset;
}
int destroy_set(struct disjset * set)
{
	free(set->data);
	free(set);
	return 0;
}
int find(struct disjset *set,int data)
{
	if(set->data[data]<0)
		return data;
	else
		return set->data[data]=find(set,set->data[data]);
}
int  union_set(struct  disjset * set,int root1,int root2)
{
	if(set->data[root1]<set->data[root2])/* root1 is deeper*/
		set->data[root2]=root1;
	else{
		if(set->data[root1]==set->data[root2])
			set->data[root2]--;
		set->data[root1]=root2;
	}
	return 0;
}
