#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "aml_graph.h"
#include "queue.h"

int locate_vex(struct aml_graph *pgraph,char c)
{
	int i;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		if(pgraph->vtexes[i].data==c)
			return i;
	return -1;
}
int first_vex(struct aml_graph* pgraph,int v,int * weight)
{
	struct aml_edge * pedge;
	pedge=pgraph->vtexes[v].first_edge;
	if(pedge){
		*weight=pedge->weight;
		return pedge->ivex==v?pedge->jvex:pedge->ivex;
	}
	return -1;
}
int next_vex(struct aml_graph*pgraph,int v,int w,int *weight)
{
	struct aml_edge *pedge;
	pedge=pgraph->vtexes[v].first_edge;
	while(pedge){
		if(pedge->ivex==v){
			if(pedge->jvex!=w)
				pedge=pedge->ilink;
			else{
				pedge=pedge->ilink;
				if(pedge){
					*weight=pedge->weight;
					return pedge->ivex+pedge->jvex-v;
				}
			}
		}
		else{
			if(pedge->ivex!=w)
				pedge=pedge->jlink;
			else{
				pedge=pedge->jlink;
				if(pedge){
					*weight=pedge->weight;
					return pedge->ivex+pedge->jvex-v;
				}
			}
		}
	}
	return -1;
}
static int visited[MAX_VERTEX_NUM];
static int visit(struct aml_vtex *pvtex)
{
	printf("%c ",pvtex->data);
	return 0;
}
static int dfs_graph(struct aml_graph* pgraph,int v)
{
	int w;
	int weight;
	visited[v]=1;
	visit(pgraph->vtexes+v);
	for(w=first_vex(pgraph,v,&weight);w>=0;w=next_vex(pgraph,v,w,&weight))
		if(!visited[w])
			dfs_graph(pgraph,w);
	return 0;
}
int depth_traverse(struct aml_graph* pgraph)
{
	int i;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	for(i=0;i<vtex_num;i++)
		if(!visited[i])
			dfs_graph(pgraph,i);
	return 0;
}
int broad_traverse(struct aml_graph* pgraph)
{
	struct queue que;
	int i;
	int weight;
	int v,w;
	int ret;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	ret=init_queue(&que);
	if(ret){
		fprintf(stderr,"init_queue error\n");
		return -1;
	}
	for(i=0;i<vtex_num;i++)
		if(!visited[i]){
			visited[i]=1;
			visit(pgraph->vtexes+i);
			ret=enqueue(&que,i);
			if(ret){
				fprintf(stderr,"enqueue error:\n");
				return -1;
			}
			while(queue_num(&que)>0){
				ret=dequeue(&que,&v);
				if(ret){
					fprintf(stderr,"dequeue_error \n");
					return -1;
				}
				for(w=first_vex(pgraph,v,&weight);w>=0;w=next_vex(pgraph,v,w,&weight))
					if(!visited[w]){
						visited[w]=1;
						visit(pgraph->vtexes+w);
						ret=enqueue(&que,w);
						if(ret){
							fprintf(stderr,"enqueue error:\n");
							return -1;
						}
					}
			}
		}
	destroy_queue(&que);
	return 0;
}
