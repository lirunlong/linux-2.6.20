#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "child_sibling.h"
#include "aml_graph.h"
#include "queue.h"


static int visited[MAX_VERTEX_NUM];

/* fix me*/
struct forest_tree * sub_tree(struct aml_graph * pgraph,int v)
{
	struct forest_tree * pforest;
	struct forest_tree* q;
	int w;
	int first;
	first=1;
	pforest=NULL;
	for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
		if(!visited[w]){
			visited[w]=1;
			if(first){
				pforest=calloc(sizeof(struct forest_tree),1);
				first=0;
				q=pforest;
			}
			else{
				q->next_sibling=calloc(sizeof(struct forest_tree),1);
				q=q->next_sibling;
			}
			q->data=pgraph->vtexes[w].data;
			q->first_child=sub_tree(pgraph,w);
		}
	return pforest;
}
struct forest_tree *build_forest(struct aml_graph * pgraph)
{
	int i;
	int vtex_num;
	struct forest_tree * pforest;
	struct forest_tree * q;
	struct forest_tree * p;
	vtex_num=pgraph->vtex_num;
	pforest=NULL;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	for(i=0;i<vtex_num;i++)
		if(!visited[i]){
			visited[i]=1;
			p=calloc(sizeof(struct forest_tree),1);
			if(!p){
				fprintf(stderr,"insufficient memory\n");
				return NULL;
			}
			if(!pforest)
				pforest=p;
			else
				q->next_sibling=p;
			q=p;
			q->data=pgraph->vtexes[i].data;
			q->first_child=sub_tree(pgraph,i);
		}
	return pforest;
}

int  destroy_forest(struct forest_tree * pforest)
{
	if(pforest){
		destroy_forest(pforest->first_child);
		destroy_forest(pforest->next_sibling);
		free(pforest);
	}
	return 0;
}

int pre_order(struct forest_tree* pforest)
{
	if(pforest){
		printf("%c ",pforest->data);
		pre_order(pforest->first_child);
		pre_order(pforest->next_sibling);
	}
	return 0;
}
int in_order(struct forest_tree * pforest)
{
	if(pforest){
		in_order(pforest->first_child);
		printf("%c ",pforest->data);
		in_order(pforest->next_sibling);
	}
	return 0;
}
/* fix me*/
struct forest_tree * build_forest_broad(struct aml_graph * pgraph)
{
	int i;
	int vtex_num;
	struct forest_tree * pforest;
	struct forest_tree * q;
	struct forest_tree *p;
	struct forest_tree *qq;
	int v,w;
	int ret;
	int first;
	struct queue que;
	pforest=NULL;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	ret=init_queue(&que);
	if(ret){
		fprintf(stderr,"init queue error\n");
		return NULL;
	}
	for(i=0;i<vtex_num;i++)
		if(!visited[i]){
			visited[i]=1;
			p=calloc(sizeof(struct forest_tree),1);/* fix me*/
			p->data=pgraph->vtexes[i].data;
			if(pforest)
				q->next_sibling=p;
			else
				pforest=p;
			q=p;
			pgraph->vtexes[i].pvtex=p;
			enqueue(&que,i);
			while(queue_num(&que)>0){
				dequeue(&que,&v);
				first=1;
				for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
					if(!visited[w]){
						visited[w]=1;
						p=calloc(sizeof(struct forest_tree),1);
						p->data=pgraph->vtexes[w].data;
						if(first){
							((struct forest_tree*)pgraph->vtexes[v].pvtex)->first_child=p;
							first=0;
						}
						else
							qq->next_sibling=p;
						qq=p;
						pgraph->vtexes[w].pvtex=p;
						enqueue(&que,w);
					}
			}
		}
	destroy_queue(&que);
	return pforest;
}
