#ifndef CHILD_SIBLING_H
#define CHILD_SIBLING_H

#include "aml_graph.h"


struct forest_tree{
	char data;
	struct forest_tree * first_child;
	struct forest_tree * next_sibling;
};
struct forest_tree *build_forest(struct aml_graph * pgraph);
int  destroy_forest(struct forest_tree * pforest);
int pre_order(struct forest_tree* pforest);
int in_order(struct forest_tree * pforest);
struct forest_tree * build_forest_broad(struct aml_graph * pgraph);
#endif
