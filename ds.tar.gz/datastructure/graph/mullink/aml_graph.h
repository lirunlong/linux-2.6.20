#ifndef AML_GRAPH_H
#define AML_GRAPH_H

#include "../graph.h"
struct aml_edge{
	int ivex;
	int jvex;
	struct aml_edge* ilink;
	struct aml_edge* jlink;
};
struct aml_vtex{
	char data;
	struct aml_edge* first_edge;
	void * pvtex;
};
struct aml_graph{
	struct aml_vtex vtexes[MAX_VERTEX_NUM];
	struct aml_edge **pedge;
	int vtex_num;
	int edge_num;
	int kind;
};
int locate_vex(struct aml_graph *pgraph,char c);
int first_vex(struct aml_graph* pgraph,int v);
int next_vex(struct aml_graph*pgraph,int v,int w);
int depth_traverse(struct aml_graph* pgraph);
int broad_traverse(struct aml_graph* pgraph);
#endif /*AML_GRAPH*/ 
