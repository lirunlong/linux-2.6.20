#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "aml_graph.h"
#include "child_sibling.h"



static int get_vtex_edge_num(struct aml_graph * pgraph)
{
	int ret;
	int vnum,anum;
	while(1){
		printf("please input the vertex num:\n");
		ret=scanf("%d",&vnum);
		getchar();
		if(ret!=1||vnum<1||vnum>MAX_VERTEX_NUM)
			printf("error input,please try again\n");
		else
			break;
	}
	pgraph->vtex_num=vnum;
	while(1){
		printf("please input the arcs num:\n");
		ret=scanf("%d",&anum);
		getchar();
		if(ret!=1||anum<0||anum>(vnum*(vnum-1))/2)
			printf("error input ,please try again\n");
		else
			break;
	}
	pgraph->edge_num=anum;
	return 0;
}
static int get_vtex(struct aml_graph * pgraph)
{
	int i;
	int vtex_num;
	int ret;
	char ch; 
	vtex_num=pgraph->vtex_num;
	i=0;
	while(i<vtex_num){
		printf("input %d vtex:\n",i);
		ret=scanf("%c",&ch);
		getchar();
		if(ret!=1||ch>'z'||ch <'a')
			printf("error input\n");
		else{
			pgraph->vtexes[i].data=ch;
			pgraph->vtexes[i].first_edge=NULL;
			i++;
		}   
	}   
	return 0;
}


static struct aml_edge * insert_edge(struct aml_graph * pgraph,int i,int j)
{
	struct aml_vtex *pvtex;
	struct aml_edge *pedge;
	pvtex=pgraph->vtexes;
	
	pedge=calloc(sizeof(struct aml_edge),1);
	if(!pedge){
		fprintf(stderr,"insufficient memory\n");
		return NULL;
	}
	pedge->ivex=i;
	pedge->jvex=j;
	pedge->ilink=pvtex[i].first_edge;
	pvtex[i].first_edge=pedge;
	pedge->jlink=pvtex[j].first_edge;
	pvtex[j].first_edge=pedge;
	return pedge;
}

static int get_edge(struct aml_graph * pgraph)
{
	int i,j,k;
	int edge_num;
	char va,ve;
	int ret;
	struct aml_edge *p;
	edge_num=pgraph->edge_num;
	i=0;
	pgraph->pedge=calloc(sizeof(struct aml_edge *),edge_num);
	if(!pgraph->pedge){
		fprintf(stderr,"insufficient memory\n");
		return -1;
	}
	while(i<edge_num){
		printf("input the %d edge's vtex :\n",i);
		ret=scanf("%c %c",&va,&ve);
		getchar();
		if(ret!=2)
			printf("error input,please try again!\n");
		else{
			j=locate_vex(pgraph,va);
			k=locate_vex(pgraph,ve);
			if(j>=0&&k>=0){
				p=insert_edge(pgraph,j,k);
				if(!p){
					fprintf(stderr,"insert_arcs error\n");
					return -1;
				}
				pgraph->pedge[i]=p;
				i++;
			}
			else
				printf("error input,please try again!\n");
		}
	}

	return 0;
}
static int destroy_edge(struct aml_graph * pgraph)
{
	int i;
	for(i=0;i<pgraph->edge_num;i++){
		if(pgraph->pedge[i]){
			free(pgraph->pedge[i]);
			pgraph->pedge[i]=NULL;
		}
	}
	for(i=0;i<pgraph->vtex_num;i++)
		pgraph->vtexes[i].first_edge=NULL;
	free(pgraph->pedge);
	return 0;
}
int main(void)
{
	int ret;
	struct aml_graph graph;
	ret=get_vtex_edge_num(&graph);
	if(ret){
		fprintf(stderr,"get num error\n");
		goto get_num_err;
	}
	ret=get_vtex(&graph);
	if(ret){
		fprintf(stderr,"get vtex error\n");
		goto get_vtex_err;
	}
	ret=get_edge(&graph);
	if(ret){
		fprintf(stderr,"get edge error\n");
		goto get_edge_err;
	}
	printf("depth travese:\n");
	ret=depth_traverse(&graph);
	if(ret){
		fprintf(stderr,"depth traverse error\n");
		goto travese_err;
	}
	printf("\n");
	printf("broad travese:\n");
	ret=broad_traverse(&graph);
	if(ret){
		fprintf(stderr,"broad traverse error\n");
		goto travese_err;
	}
	printf("\n");

	struct forest_tree * ptree;

	printf("***************build tree********\n");
	ptree=build_forest(&graph);
	printf("pre order:\n");
	pre_order(ptree);
	printf("\n");
	printf("in order:\n");
	in_order(ptree);
	printf("\n");
	destroy_forest(ptree);

	printf("*****************build tree broad *************\n");
	ptree=build_forest_broad(&graph);
	printf("pre order:\n");
	pre_order(ptree);
	printf("\n");
	printf("in order:\n");
	in_order(ptree);
	printf("\n");
	destroy_forest(ptree);

	destroy_edge(&graph);
	return 0;
travese_err:
get_edge_err:
	destroy_edge(&graph);
get_vtex_err:
get_num_err:
	return -1;
}
