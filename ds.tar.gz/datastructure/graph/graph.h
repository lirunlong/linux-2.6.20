#ifndef GRAPH_H
#define GRAPH_H

#define MAX_VERTEX_NUM 			20
enum{
	dg,
	dn,
	udg,
	udn
};

#endif /*GRAPH_H*/ 
