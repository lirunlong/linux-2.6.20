#include <stdio.h>


#include "m_graph.h"
#define DEBUG 	1


static int get_vertex_arcs_num(int *vertex_num,int *arcs_num)
{
	int vtex,arcs;
	int ret;
	printf("pelase input vertex_num:\n");
	while(1){
		ret=scanf("%d",&vtex);
		getchar();
		if(!ret||vtex>20||vtex<1)
			printf("please input a valid num \n");
		else{
			*vertex_num=vtex;
			break;
		}
	}
	printf("please input arcs_num:\n");
	while(1){
		ret=scanf("%d",&arcs);
		getchar();
		if(!ret||arcs>(vtex*(vtex-1)/2)||arcs<0)
			printf("please input a valid num\n");
		else{
			*arcs_num=arcs;
			break;
		}
	}
#if DEBUG
	printf("vertex_num=%d,arcs_num=%d\n",*vertex_num,*arcs_num);
#endif
	return 0;
}
static int  get_vertex_value(struct m_graph*pgraph)
{
	int i;
	int vertex_num;
	char c;
	int ret;
	vertex_num=pgraph->vertex_num;
	i=0;
	while(i<vertex_num){
		printf("input %d vertex\n",i);
		ret=scanf("%c",&c);
		getchar();
		if(!ret||c>'z'||c<'a')
			printf("error input\n");
		else{
			pgraph->vtex[i]=c;
			i++;
		}
	}
	return 0;
}

static int  init_arcs(struct m_graph*pgraph)
{
	int i,j;
	int vertex_num;
	vertex_num=pgraph->vertex_num;
	for(i=0;i<vertex_num;i++)
		for(j=0;j<vertex_num;j++)
			pgraph->arcs[i][j].adj=0;
	return 0;
}

static int get_arcs(struct m_graph * pgraph)
{
	int i;
	int j,k;
	char va,ve;
	int ret;
	int arcs_num;
	arcs_num=pgraph->arcs_num;
	i=0;
	while(i<arcs_num){
		printf("input the %d arc's vtex :\n",i);
		ret=scanf("%c %c",&va,&ve);
		getchar();
		if(ret!=2)
			printf("error input\n");
		else{
			j=locate_vex(pgraph,va);
			k=locate_vex(pgraph,ve);
			if(j>=0&&k>=0){
				pgraph->arcs[j][k].adj=1;
				pgraph->arcs[k][j].adj=1;
				i++;
			}
			else
				printf("error input\n");

		}
	}
	return 0;
}

int create_matrix_graph(struct m_graph * pgraph)
{
	int ret;
	int vertex_num,arcs_num;
	ret=get_vertex_arcs_num(&vertex_num,&arcs_num);
	if(ret)
		return -1;
	pgraph->vertex_num=vertex_num;
	pgraph->arcs_num=arcs_num;
	ret=get_vertex_value(pgraph);
	if(ret)
		return -1;
	ret=init_arcs(pgraph);
	if(ret)
		return -1;
	ret=get_arcs(pgraph);
	if(ret)
		return -1;
	return 0;
}


int main(void)
{
	struct m_graph graph;
	int ret;
	ret=create_matrix_graph(&graph);
	if(ret){
		fprintf(stderr,"create graph error\n");
		return -1;
	}
#if DEBUG
	int i,j;
	int v_num;
	v_num=graph.vertex_num;
	for(i=0;i<v_num;i++){
		for(j=0;j<v_num;j++)
			printf("%d ",graph.arcs[i][j].adj);
		printf("\n");
	}
#endif
	depth_traverse(&graph);
	printf("\n");
	broad_traverse(&graph);
	printf("\n");
	return 0;
}
