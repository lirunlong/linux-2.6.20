#ifndef M_GRAPH_H
#define M_GRAPH_H

#include "../graph.h"


struct arc_cell{
	int adj;
	void * info;
};

struct m_graph{
	char vtex[MAX_VERTEX_NUM];
	struct arc_cell arcs[MAX_VERTEX_NUM][MAX_VERTEX_NUM];
	int arcs_num;
	int vertex_num;
	int graph_kind;
};

/*
 * return the index of c, if not find ,return -1;
 */
int locate_vex(struct m_graph *pgraph,char c);

int first_vex(struct m_graph* pgraph,int v);

int next_vex(struct m_graph*pgraph,int v,int w);

int depth_traverse(struct m_graph* pgraph);
int broad_traverse(struct m_graph* pgraph);
#endif    /*M_GRAPH_H*/ 
