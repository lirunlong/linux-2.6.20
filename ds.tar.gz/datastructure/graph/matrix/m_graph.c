#include <stdio.h>


#include "m_graph.h"
#include "queue.h"


int locate_vex(struct m_graph * pgraph,char c)
{
	int i;
	int vertex_num;
	vertex_num=pgraph->vertex_num;
	for(i=0;i<vertex_num;i++){
		if(pgraph->vtex[i]==c)
			return i;
	}
	return -1;
}

static int visited[MAX_VERTEX_NUM];
static int dfs_graph(struct m_graph*pgraph,int i)
{
	int w;
	visited[i]=1;
	printf("%c ",pgraph->vtex[i]);
	for(w=first_vex(pgraph,i);w>=0;w=next_vex(pgraph,i,w))
		if(!visited[w])
			dfs_graph(pgraph,w);
	return 0;
}
int depth_traverse(struct m_graph*pgraph)
{
	int i;
	int vertex_num;
	vertex_num=pgraph->vertex_num;
	for(i=0;i<vertex_num;i++)
		visited[i]=0;
	for(i=0;i<vertex_num;i++)
		if(!visited[i])
			dfs_graph(pgraph,i);
	return 0;
}
int broad_traverse(struct m_graph* pgraph)
{
	int i;
	int v;
	int w;
	struct queue que;
	int vertex_num;
	int ret;
	ret=init_queue(&que);
	if(ret){
		fprintf(stderr,"init_queue error\n");
		return -1;
	}
	vertex_num=pgraph->vertex_num;
	for(i=0;i<vertex_num;i++)
		visited[i]=0;
	for(i=0;i<vertex_num;i++){
		if(!visited[i]){
			visited[i]=1;
			printf("%c ",pgraph->vtex[i]);
			enqueue(&que,i);
			while(queue_num(&que)){
				ret=dequeue(&que,&v);
				if(ret){
					fprintf(stderr,"dequeue error\n");
					return -1;
				}
				for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w)){
					if(!visited[w]){
						printf("%c ",pgraph->vtex[w]);
						visited[w]=1;
						enqueue(&que,w);
					}
				}
			}
		}
	}
	destroy_queue(&que);
	return 0;
}

int first_vex(struct m_graph* pgraph,int v)
{
	int i;
	int vtex_num;
	vtex_num=pgraph->vertex_num;
	for(i=0;i<vtex_num;i++)
		if(pgraph->arcs[v][i].adj>0)
			return i;
	return -1;
}

int next_vex(struct m_graph*pgraph,int v,int w)
{
	int i;
	int vtex_num;
	vtex_num=pgraph->vertex_num;
	for(i=w+1;i<vtex_num;i++)
		if(pgraph->arcs[v][i].adj>0)
			return i;
	return -1;
}
