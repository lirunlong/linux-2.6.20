#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "al_graph.h"
#include "unweighted.h"
#include "queue.h"

static struct table_record records[MAX_VERTEX_NUM];
static int init_table(struct al_graph * pgraph,int v)
{
	int vtex_num;
	int i;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++){
		records[i].v=i;
		records[i].known=0;
		records[i].dist=-1;
		records[i].path=-1;
	}
	records[v].dist=0;
	return 0;
}
static int path(struct al_graph * pgraph,int  v)
{
	if(records[v].path!=-1)
		path(pgraph,records[v].path);
	printf("%c ",pgraph->vtexes[v].data);
	return 0;
}
static int print_path(struct al_graph*pgraph,char c)
{
	int vnum,i;
	vnum=pgraph->vtex_num;
	printf("the distance away from %c \n",c);
	for(i=0;i<vnum;i++){
		if(records[i].dist==-1)
			printf("%c is no path \n",pgraph->vtexes[i].data);
		else{
			printf("%c distance is %d ,path is:",pgraph->vtexes[i].data,records[i].dist);
			path(pgraph,i);
			printf("\n");
		}
	}
	return 0;
}
int unweighted(struct al_graph *pgraph,char c)
{
	int vnum,i,w;
	int v=locate_vex(pgraph,c);
	if(v==-1)
		return -1;
	vnum=pgraph->vtex_num;
	init_table(pgraph,v);
	for(i=0;i<vnum;i++){
		for(v=0;v<vnum;v++)
			if(!records[v].known&&records[v].dist==i){
				records[v].known=1;
				for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
					if(records[w].dist==-1){
						records[w].dist=i+1;
						records[w].path=v;
					}

			}
	}
	print_path(pgraph,c);
	return 0;
}
static struct queue que;
int unweighted2(struct al_graph * pgraph,char c)
{
	int v,w,ret;
	v=locate_vex(pgraph,c);
	if(v==-1)
		return -1;
	init_table(pgraph,v);
	init_queue(&que);
	ret=enqueue(&que,v);
	if(ret)
		return -1;
	while(queue_num(&que)>0){
		ret=dequeue(&que,&v);
		if(ret)
			return -1;
		for(w=first_vex(pgraph,v);w>=0;w=next_vex(pgraph,v,w))
			if(records[w].dist==-1){
				records[w].dist=records[v].dist+1;
				records[w].path=v;
				ret=enqueue(&que,w);
				if(ret)
					return -1;
			}
	}
	destroy_queue(&que);
	print_path(pgraph,c);
	return 0;
}
