#ifndef UNWEIGHTED_H
#define UNWEIGHTED_H


struct table_record
{
	int v;
	int known;
	int dist;
	int path;
};
int  unweighted(struct al_graph *,char c);
int unweighted2(struct al_graph *,char c);
#endif /*UNWEIGHTED*/ 
