#ifndef AL_GRAPH_H
#define AL_GRAPH_H
#include "../../graph.h"

struct arc{
	int index;
	struct arc * next_arc;
	void * arc_info;
};

struct vtex_node{
	char data;
	struct arc *first_arc;
};

struct al_graph{
	struct vtex_node vtexes[MAX_VERTEX_NUM];
	int vtex_num;
	int arc_num;
	int kind;
};

int locate_vex(struct al_graph *pgraph,char c);
int first_vex(struct al_graph* pgraph,int v);
int next_vex(struct al_graph*pgraph,int v,int w);
int depth_traverse(struct al_graph* pgraph);
int broad_traverse(struct al_graph* pgraph);

#endif   /*AL_GRAPH_H*/ 
