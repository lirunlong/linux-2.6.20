#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "al_graph.h"
#include "dijkstra.h"
#include "heap.h"

static struct table_record  recs[MAX_VERTEX_NUM];


static struct  heap hp;

static int update_rec(struct al_graph * pgraph,int v)
{
	int w,weight;
	for(w=first_vex(pgraph,v,&weight);w>=0;w=next_vex(pgraph,v,w,&weight))
		if(!recs[w].known){
			if(recs[w].dist==-1||recs[w].dist>recs[v].dist+weight){
				recs[w].dist=recs[v].dist+weight;
				recs[w].path=v;
				insert_elem(&hp,recs+w);
			}
		}
	return 0;
}

static int find_min(int vnum)
{
    /*
	 *int min=-1;
	 *int i;
	 *for(i=0;i<vnum;i++)
	 *    if(!recs[i].known)
	 *        if(min==-1||(unsigned)recs[i].dist<(unsigned)recs[min].dist)
	 *            min=i;
	 *return min;
     */
	int ret;
	struct table_record *minrec;
	while(1){
		ret=delete_min(&hp,&minrec);
		if(ret)
			return -1;
		else if(!minrec->known)
			return minrec->v;
	}
}
static int init_table(struct al_graph * pgraph,int v)
{
	int i;
	int vnum;
	vnum=pgraph->vtex_num;
	for(i=0;i<vnum;i++){
		recs[i].v=i;
		recs[i].known=0;
		recs[i].dist=-1;
		recs[i].path=-1;
	}
	recs[v].dist=0;
	insert_elem(&hp,recs+v);
	return 0;
}
static int path(struct al_graph * pgraph,int v)
{
	if(recs[v].path!=-1){
		path(pgraph,recs[v].path);
		printf("->");
	}
	printf("%c",pgraph->vtexes[v].data);
	return 0;
}
static int print_path(struct al_graph *pgraph,char c)
{
	int i;
	int vnum;
	vnum=pgraph->vtex_num;
	for(i=0;i<vnum;i++){
		if(recs[i].dist==-1)
			printf("there is no path from %c to %c\n",c,pgraph->vtexes[i].data);
		else{
			printf("the distance  from %c to  %c is %d:",c,pgraph->vtexes[i].data,recs[i].dist);
			path(pgraph,i);
			printf("\n");
		}
	}
	return 0;
}
int weighted(struct al_graph * pgraph,char c)
{
	int v;
	int vnum;
	init_heap(&hp,MAX_VERTEX_NUM);
	v=locate_vex(pgraph,c);
	if(v==-1)
		return -1;
	vnum=pgraph->vtex_num;
	init_table(pgraph,v);
	while(1){
		v=find_min(vnum);
		if(v==-1)
			break;
		recs[v].known=1;
		update_rec(pgraph,v);
	}
	print_path(pgraph,c);
	destroy_heap(&hp);
	return 0;
}
