#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "heap.h"




int init_heap(struct heap * pheap,int size)
{
	if(size<1)
		return -1;
	pheap->capacity=size;
	pheap->cur_size=0;
	pheap->data=calloc(sizeof(struct table_record*),size+1);
	if(!pheap->data){
		fprintf(stderr,"insuficient memory\n");
		return -1;
	}
	return 0;
}
int destroy_heap(struct heap * pheap)
{
	free(pheap->data);
	return 0;
}
int delete_min(struct heap * pheap,struct table_record**pdata)
{
	int index,j;
	struct table_record * tmp;
	if(pheap->cur_size<1)
		return -1;
	*pdata=pheap->data[1];
	tmp=pheap->data[pheap->cur_size--];
	index=1;
	for(j=index<<1;j<=pheap->cur_size;j<<=1){
		if(j+1<=pheap->cur_size&&pheap->data[j]->dist>pheap->data[j+1]->dist)
			j++;
		if(tmp->dist>pheap->data[j]->dist){
			pheap->data[index]=pheap->data[j];
			index=j;
		}
		else
			break;
	}
	pheap->data[index]=tmp;
	return 0;
}
int insert_elem(struct heap * pheap,struct table_record *pdata)
{
	int index,i;
	if(pheap->cur_size==pheap->capacity)
		return -1;
	pheap->cur_size++;
	i=pheap->cur_size;
	for(index=i>>1;index>=1;index>>=1)
		if(pheap->data[index]->dist>pdata->dist){
			pheap->data[i]=pheap->data[index];
			i=index;
		}
		else
			break;
	pheap->data[i]=pdata;
	return 0;
}
