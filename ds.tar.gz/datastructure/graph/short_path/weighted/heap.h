#pragma once

#include "dijkstra.h"

struct heap{
	int capacity;
	int cur_size;
	struct table_record ** data;
};


int init_heap(struct heap * pheap,int size);
int destroy_heap(struct heap * pheap);
int delete_min(struct heap * pheap,struct table_record **pdata);
int insert_elem(struct heap * pehap,struct table_record*pdata);
