#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "al_graph.h"
#include "queue.h"

int locate_vex(struct al_graph *pgraph,char c)
{
	int i;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++){
		if(pgraph->vtexes[i].data==c)
			return i;
	}
	return -1;
}
int first_vex(struct al_graph* pgraph,int v,int *weight)
{
	struct arc * parc;
	if(v<pgraph->vtex_num&&v>=0){
		parc=pgraph->vtexes[v].first_arc;
		if(parc){
			*weight=parc->weight;
			return parc->index;
		}
	}
	return -1;
}
int next_vex(struct al_graph*pgraph,int v,int w,int *weight){
	struct arc * parc;
	if(v<pgraph->vtex_num&&v>=0&&w<pgraph->vtex_num&&w>=0){
		parc=pgraph->vtexes[v].first_arc;
		while(parc&&parc->index!=w)
			parc=parc->next_arc;
		if(parc&&parc->next_arc){
			*weight=parc->next_arc->weight;
			return parc->next_arc->index;
		}
	}
	return -1;
}
static int visited[MAX_VERTEX_NUM];
static int visit(struct vtex_node *pvtex)
{
	printf("%c ",pvtex->data);
	return 0;
}
static int dfs_graph(struct al_graph* pgraph,int v)
{
	int weight;
	int w;
	visited[v]=1;
	visit(pgraph->vtexes+v);
	for(w=first_vex(pgraph,v,&weight);w>=0;w=next_vex(pgraph,v,w,&weight))
		if(!visited[w])
			dfs_graph(pgraph,w);
	return 0;
}
int depth_traverse(struct al_graph* pgraph)
{
	int i;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	for(i=0;i<vtex_num;i++)
		if(!visited[i])
			dfs_graph(pgraph,i);
	return 0;
}
int broad_traverse(struct al_graph* pgraph)
{
	int weight;
	struct queue que;
	int i;
	int v;
	int w;
	int ret;
	int vtex_num;
	vtex_num=pgraph->vtex_num;
	init_queue(&que);
	for(i=0;i<vtex_num;i++)
		visited[i]=0;
	for(i=0;i<vtex_num;i++)
		if(!visited[i]){
			visited[i]=1;
			visit(pgraph->vtexes+i);
			ret=enqueue(&que,i);
			if(ret){
				fprintf(stderr,"enqueue error\n");
				goto out;
			}
			while(queue_num(&que)>0){
				ret=dequeue(&que,&v);
				if(ret){
					fprintf(stderr,"dequeue error\n");
					goto out;
				}
				for(w=first_vex(pgraph,v,&weight);w>=0;w=next_vex(pgraph,v,w,&weight)){
					if(!visited[w]){
						visited[w]=1;
						visit(pgraph->vtexes+w);
						ret=enqueue(&que,w);
						if(ret){
							fprintf(stderr,"enqueue error\n");
							goto out;
						}
					}
				}
			}
		}
	destroy_queue(&que);
	return 0;
out:
	destroy_queue(&que);
	return -1;
}
