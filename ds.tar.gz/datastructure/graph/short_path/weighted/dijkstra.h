#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include "al_graph.h"


struct table_record{
	int v;
	int known;
	int dist;
	int path;
};
int weighted(struct al_graph * pgraph,char c);

#endif /*DIJKSTRA_H*/ 
